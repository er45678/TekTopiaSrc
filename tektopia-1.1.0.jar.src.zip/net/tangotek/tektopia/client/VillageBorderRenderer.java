/*     */ package net.tangotek.tektopia.client;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.tangotek.tektopia.VillageClient;
/*     */ 
/*     */ public class VillageBorderRenderer
/*     */ {
/*  21 */   private static final ResourceLocation FORCEFIELD_TEXTURES = new ResourceLocation("textures/misc/forcefield.png");
/*     */   
/*  23 */   private VillageClient villageClient = null;
/*     */ 
/*     */   
/*     */   public VillageBorderRenderer() {
/*  27 */     MinecraftForge.EVENT_BUS.register(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void renderWorldLast(RenderWorldLastEvent event) {
/*  35 */     if (this.villageClient == null) {
/*     */       return;
/*     */     }
/*  38 */     Minecraft minecraft = Minecraft.func_71410_x();
/*  39 */     WorldClient world = minecraft.field_71441_e;
/*  40 */     EntityPlayerSP player = minecraft.field_71439_g;
/*  41 */     if (world == null || player == null) {
/*     */       return;
/*     */     }
/*     */     
/*  45 */     renderBorder((Entity)player, event.getPartialTicks());
/*     */   }
/*     */   
/*     */   public void updateVillage(VillageClient vc) {
/*  49 */     this.villageClient = vc;
/*     */   }
/*     */   
/*     */   private int getBorderDistance(BlockPos pos) {
/*  53 */     int dist = Integer.MAX_VALUE;
/*     */     
/*  55 */     dist = Math.min(dist, Math.abs(pos.func_177958_n() - this.villageClient.getMaxX()));
/*  56 */     dist = Math.min(dist, Math.abs(pos.func_177958_n() - this.villageClient.getMinX()));
/*  57 */     dist = Math.min(dist, Math.abs(pos.func_177952_p() - this.villageClient.getMaxZ()));
/*  58 */     dist = Math.min(dist, Math.abs(pos.func_177952_p() - this.villageClient.getMinZ()));
/*  59 */     return dist;
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderBorder(Entity entityIn, float partialTicks) {
/*  64 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  65 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  66 */     double RENDER_DISTANCE = 8.0D;
/*  67 */     double RENDER_Y_DELTA = 2.0D;
/*  68 */     double RENDER_WALL_WIDTH = 10.0D;
/*     */     
/*  70 */     int borderDistance = getBorderDistance(entityIn.func_180425_c());
/*     */     
/*  72 */     if (borderDistance < 8.0D) {
/*     */       
/*  74 */       double colorAlpha = 1.0D - borderDistance / 8.0D;
/*  75 */       colorAlpha = Math.pow(colorAlpha, 2.0D);
/*  76 */       double entityX = entityIn.field_70142_S + (entityIn.field_70165_t - entityIn.field_70142_S) * partialTicks;
/*  77 */       double entityY = entityIn.field_70137_T + (entityIn.field_70163_u - entityIn.field_70137_T) * partialTicks;
/*  78 */       double entityZ = entityIn.field_70136_U + (entityIn.field_70161_v - entityIn.field_70136_U) * partialTicks;
/*  79 */       GlStateManager.func_179147_l();
/*  80 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*  81 */       Minecraft.func_71410_x().func_110434_K().func_110577_a(FORCEFIELD_TEXTURES);
/*  82 */       GlStateManager.func_179132_a(false);
/*  83 */       GlStateManager.func_179094_E();
/*  84 */       int color = 2138367;
/*  85 */       float colorR = (color >> 16 & 0xFF) / 255.0F;
/*  86 */       float colorG = (color >> 8 & 0xFF) / 255.0F;
/*  87 */       float colorB = (color & 0xFF) / 255.0F;
/*  88 */       GlStateManager.func_179131_c(colorR, colorG, colorB, (float)colorAlpha);
/*  89 */       GlStateManager.func_179136_a(-3.0F, -3.0F);
/*  90 */       GlStateManager.func_179088_q();
/*  91 */       GlStateManager.func_179092_a(516, 0.1F);
/*  92 */       GlStateManager.func_179141_d();
/*  93 */       GlStateManager.func_179129_p();
/*  94 */       float f3 = (float)(Minecraft.func_71386_F() % 3000L) / 3000.0F;
/*  95 */       float f4 = 0.0F;
/*  96 */       float f5 = 0.0F;
/*  97 */       float f6 = 128.0F;
/*  98 */       bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  99 */       bufferbuilder.func_178969_c(-entityX, -entityY, -entityZ);
/* 100 */       double d8 = Math.max(MathHelper.func_76128_c(entityZ - 10.0D), this.villageClient.getMinZ());
/* 101 */       double d9 = Math.min(MathHelper.func_76143_f(entityZ + 10.0D), this.villageClient.getMaxZ());
/*     */ 
/*     */       
/* 104 */       if (Math.abs(entityX - this.villageClient.getMaxX()) < 8.0D) {
/*     */         
/* 106 */         float f7 = 0.0F;
/*     */         
/* 108 */         for (double d10 = d8; d10 < d9; f7 += 0.5F) {
/*     */           
/* 110 */           double d11 = Math.min(1.0D, d9 - d10);
/* 111 */           float f8 = (float)d11 * 0.5F;
/* 112 */           bufferbuilder.func_181662_b(this.villageClient.getMaxX(), entityY + 2.0D, d10).func_187315_a((f3 + f7), (f3 + 0.0F)).func_181675_d();
/* 113 */           bufferbuilder.func_181662_b(this.villageClient.getMaxX(), entityY + 2.0D, d10 + d11).func_187315_a((f3 + f8 + f7), (f3 + 0.0F)).func_181675_d();
/* 114 */           bufferbuilder.func_181662_b(this.villageClient.getMaxX(), entityY - 2.0D, d10 + d11).func_187315_a((f3 + f8 + f7), (f3 + 128.0F)).func_181675_d();
/* 115 */           bufferbuilder.func_181662_b(this.villageClient.getMaxX(), entityY - 2.0D, d10).func_187315_a((f3 + f7), (f3 + 128.0F)).func_181675_d();
/* 116 */           d10++;
/*     */         } 
/*     */       } 
/*     */       
/* 120 */       if (Math.abs(entityX - this.villageClient.getMinX()) < 8.0D) {
/*     */         
/* 122 */         float f9 = 0.0F;
/*     */         
/* 124 */         for (double d12 = d8; d12 < d9; f9 += 0.5F) {
/*     */           
/* 126 */           double d15 = Math.min(1.0D, d9 - d12);
/* 127 */           float f12 = (float)d15 * 0.5F;
/* 128 */           bufferbuilder.func_181662_b(this.villageClient.getMinX(), entityY + 2.0D, d12).func_187315_a((f3 + f9), (f3 + 0.0F)).func_181675_d();
/* 129 */           bufferbuilder.func_181662_b(this.villageClient.getMinX(), entityY + 2.0D, d12 + d15).func_187315_a((f3 + f12 + f9), (f3 + 0.0F)).func_181675_d();
/* 130 */           bufferbuilder.func_181662_b(this.villageClient.getMinX(), entityY - 2.0D, d12 + d15).func_187315_a((f3 + f12 + f9), (f3 + 128.0F)).func_181675_d();
/* 131 */           bufferbuilder.func_181662_b(this.villageClient.getMinX(), entityY - 2.0D, d12).func_187315_a((f3 + f9), (f3 + 128.0F)).func_181675_d();
/* 132 */           d12++;
/*     */         } 
/*     */       } 
/*     */       
/* 136 */       d8 = Math.max(MathHelper.func_76128_c(entityX - 10.0D), this.villageClient.getMinX());
/* 137 */       d9 = Math.min(MathHelper.func_76143_f(entityX + 10.0D), this.villageClient.getMaxX());
/*     */       
/* 139 */       if (Math.abs(entityZ - this.villageClient.getMaxZ()) < 8.0D) {
/*     */         
/* 141 */         float f10 = 0.0F;
/*     */         
/* 143 */         for (double d13 = d8; d13 < d9; f10 += 0.5F) {
/*     */           
/* 145 */           double d16 = Math.min(1.0D, d9 - d13);
/* 146 */           float f13 = (float)d16 * 0.5F;
/* 147 */           bufferbuilder.func_181662_b(d13, entityY + 2.0D, this.villageClient.getMaxZ()).func_187315_a((f3 + f10), (f3 + 0.0F)).func_181675_d();
/* 148 */           bufferbuilder.func_181662_b(d13 + d16, entityY + 2.0D, this.villageClient.getMaxZ()).func_187315_a((f3 + f13 + f10), (f3 + 0.0F)).func_181675_d();
/* 149 */           bufferbuilder.func_181662_b(d13 + d16, entityY - 2.0D, this.villageClient.getMaxZ()).func_187315_a((f3 + f13 + f10), (f3 + 128.0F)).func_181675_d();
/* 150 */           bufferbuilder.func_181662_b(d13, entityY - 2.0D, this.villageClient.getMaxZ()).func_187315_a((f3 + f10), (f3 + 128.0F)).func_181675_d();
/* 151 */           d13++;
/*     */         } 
/*     */       } 
/*     */       
/* 155 */       if (Math.abs(entityZ - this.villageClient.getMinZ()) < 8.0D) {
/*     */         
/* 157 */         float f11 = 0.0F;
/*     */         
/* 159 */         for (double d14 = d8; d14 < d9; f11 += 0.5F) {
/*     */           
/* 161 */           double d17 = Math.min(1.0D, d9 - d14);
/* 162 */           float f14 = (float)d17 * 0.5F;
/* 163 */           bufferbuilder.func_181662_b(d14, entityY + 2.0D, this.villageClient.getMinZ()).func_187315_a((f3 + f11), (f3 + 0.0F)).func_181675_d();
/* 164 */           bufferbuilder.func_181662_b(d14 + d17, entityY + 2.0D, this.villageClient.getMinZ()).func_187315_a((f3 + f14 + f11), (f3 + 0.0F)).func_181675_d();
/* 165 */           bufferbuilder.func_181662_b(d14 + d17, entityY - 2.0D, this.villageClient.getMinZ()).func_187315_a((f3 + f14 + f11), (f3 + 128.0F)).func_181675_d();
/* 166 */           bufferbuilder.func_181662_b(d14, entityY - 2.0D, this.villageClient.getMinZ()).func_187315_a((f3 + f11), (f3 + 128.0F)).func_181675_d();
/* 167 */           d14++;
/*     */         } 
/*     */       } 
/*     */       
/* 171 */       tessellator.func_78381_a();
/* 172 */       bufferbuilder.func_178969_c(0.0D, 0.0D, 0.0D);
/* 173 */       GlStateManager.func_179089_o();
/* 174 */       GlStateManager.func_179118_c();
/* 175 */       GlStateManager.func_179136_a(0.0F, 0.0F);
/* 176 */       GlStateManager.func_179113_r();
/* 177 */       GlStateManager.func_179141_d();
/* 178 */       GlStateManager.func_179084_k();
/* 179 */       GlStateManager.func_179121_F();
/* 180 */       GlStateManager.func_179132_a(true);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\client\VillageBorderRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */