/*    */ package net.tangotek.tektopia.structures;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.item.EntityItemFrame;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.tangotek.tektopia.Village;
/*    */ 
/*    */ 
/*    */ public class VillageStructureLibrary
/*    */   extends VillageStructure
/*    */ {
/*    */   protected VillageStructureLibrary(World world, Village v, EntityItemFrame itemFrame) {
/* 15 */     super(world, v, itemFrame, VillageStructureType.LIBRARY, "Library");
/*    */   }
/*    */ 
/*    */   
/*    */   protected void scanSpecialBlock(BlockPos pos, Block block) {
/* 20 */     if (block == Blocks.field_150381_bn) {
/* 21 */       addSpecialBlock(Blocks.field_150381_bn, pos);
/*    */     }
/* 23 */     else if (block == Blocks.field_150342_X) {
/* 24 */       addSpecialBlock(Blocks.field_150342_X, pos);
/*    */     }
/* 26 */     else if (block == Blocks.field_150462_ai) {
/* 27 */       addSpecialBlock(Blocks.field_150462_ai, pos);
/*    */     } 
/*    */     
/* 30 */     super.scanSpecialBlock(pos, block);
/*    */   }
/*    */ 
/*    */   
/*    */   public void update() {
/* 35 */     super.update();
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\structures\VillageStructureLibrary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */