/*    */ package net.tangotek.tektopia.structures;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.IEntityLivingData;
/*    */ import net.minecraft.entity.item.EntityItemFrame;
/*    */ import net.minecraft.entity.passive.EntityAnimal;
/*    */ import net.minecraft.entity.passive.EntityChicken;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.init.SoundEvents;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.tangotek.tektopia.EntityTagType;
/*    */ import net.tangotek.tektopia.ItemTagType;
/*    */ import net.tangotek.tektopia.ModItems;
/*    */ import net.tangotek.tektopia.Village;
/*    */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*    */ 
/*    */ public class VillageStructureChickenCoop extends VillageStructureRancherPen {
/*    */   protected VillageStructureChickenCoop(World world, Village v, EntityItemFrame itemFrame) {
/* 21 */     super(world, v, itemFrame, VillageStructureType.CHICKEN_COOP, 1, "Chicken Coop");
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityAnimal spawnAnimal(BlockPos pos) {
/* 26 */     EntityChicken animal = new EntityChicken(this.world);
/* 27 */     animal.func_70012_b(pos.func_177958_n() + 0.5D, pos.func_177956_o(), pos.func_177952_p() + 0.5D, 0.0F, 0.0F);
/* 28 */     animal.func_180482_a(this.world.func_175649_E(pos), (IEntityLivingData)null);
/* 29 */     this.world.func_72838_d((Entity)animal);
/* 30 */     ModEntities.makeTaggedEntity((Entity)animal, EntityTagType.VILLAGER);
/* 31 */     return (EntityAnimal)animal;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getAnimalClass() {
/* 36 */     return EntityChicken.class;
/*    */   }
/*    */   public static Predicate<ItemStack> isFood() {
/* 39 */     return p -> (p.func_77973_b() == Items.field_151014_N || p.func_77973_b() == Items.field_185163_cU);
/*    */   }
/*    */   
/*    */   public EntityVillagerTek.VillagerThought getNoFoodThought() {
/* 43 */     return EntityVillagerTek.VillagerThought.CHICKEN_FOOD;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityVillagerTek.VillagerThought getNoHarvestThought() {
/* 49 */     return EntityVillagerTek.VillagerThought.BUCKET;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updateAnimal(EntityAnimal animal) {
/* 54 */     if (animal instanceof EntityChicken) {
/* 55 */       EntityChicken chicken = (EntityChicken)animal;
/* 56 */       chicken.field_70887_j = 9999999;
/* 57 */       if (!this.world.field_72995_K && !chicken.func_70631_g_() && !chicken.func_152116_bZ())
/*    */       {
/*    */         
/* 60 */         if (chicken.func_70681_au().nextInt(500) == 0) {
/* 61 */           chicken.func_184185_a(SoundEvents.field_187665_Y, 1.0F, (chicken.func_70681_au().nextFloat() - chicken.func_70681_au().nextFloat()) * 0.2F + 1.0F);
/* 62 */           chicken.func_70099_a(ModItems.makeTaggedItem(new ItemStack(Items.field_151110_aK), ItemTagType.VILLAGER), 0.0F);
/*    */         } 
/*    */       }
/*    */     } 
/* 66 */     super.updateAnimal(animal);
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\structures\VillageStructureChickenCoop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */