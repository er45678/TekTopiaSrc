/*    */ package net.tangotek.tektopia.entities;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ import net.minecraft.network.datasync.DataParameter;
/*    */ import net.minecraft.network.datasync.DataSerializers;
/*    */ import net.minecraft.network.datasync.EntityDataManager;
/*    */ import net.minecraft.world.World;
/*    */ import net.tangotek.tektopia.ModSoundEvents;
/*    */ import net.tangotek.tektopia.ProfessionType;
/*    */ import net.tangotek.tektopia.TekVillager;
/*    */ import net.tangotek.tektopia.VillagerRole;
/*    */ import net.tangotek.tektopia.entities.ai.EntityAIPerformTavern;
/*    */ import net.tangotek.tektopia.entities.ai.EntityAIPerformWander;
/*    */ 
/*    */ public class EntityBard extends EntityVillagerTek {
/* 17 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityBard.class);
/*    */   
/* 19 */   private static final DataParameter<Byte> PERFORMANCE = EntityDataManager.func_187226_a(EntityBard.class, DataSerializers.field_187191_a);
/* 20 */   private static final DataParameter<Boolean> PERFORM_WANDER = EntityDataManager.func_187226_a(EntityBard.class, DataSerializers.field_187198_h);
/* 21 */   private static final DataParameter<Boolean> PERFORM_TAVERN = EntityDataManager.func_187226_a(EntityBard.class, DataSerializers.field_187198_h);
/* 22 */   private int lastPerformanceTick = 0;
/*    */   
/*    */   static {
/* 25 */     animHandler.addAnim("tektopia", "villager_flute_1", "bard_m", true);
/* 26 */     EntityVillagerTek.setupAnimations(animHandler, "bard_m");
/*    */   }
/*    */   
/*    */   public EntityBard(World worldIn) {
/* 30 */     super(worldIn, ProfessionType.BARD, VillagerRole.VILLAGER.value);
/*    */   }
/*    */   
/*    */   public AnimationHandler getAnimationHandler() {
/* 34 */     return animHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_70088_a() {
/* 40 */     super.func_70088_a();
/* 41 */     registerAIFilter("perform_wander", PERFORM_WANDER);
/* 42 */     registerAIFilter("perform_tavern", PERFORM_TAVERN);
/*    */     
/* 44 */     this.field_70180_af.func_187214_a(PERFORMANCE, Byte.valueOf((byte)0));
/*    */   }
/*    */   
/*    */   protected void func_184651_r() {
/* 48 */     super.func_184651_r();
/*    */     
/* 50 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIPerformTavern(this));
/* 51 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIPerformWander(this));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void addTask(int priority, EntityAIBase task) {
/* 60 */     if (task instanceof net.tangotek.tektopia.entities.ai.EntityAIWanderStructure) {
/*    */       return;
/*    */     }
/* 63 */     super.addTask(priority, task);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPerforming() {
/* 68 */     return (((Byte)this.field_70180_af.func_187225_a(PERFORMANCE)).byteValue() != 0);
/*    */   }
/*    */   
/*    */   public ModSoundEvents.Performance getPerformance() {
/* 72 */     Byte perf = (Byte)this.field_70180_af.func_187225_a(PERFORMANCE);
/* 73 */     return ModSoundEvents.Performance.valueOf(perf.byteValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPerformance(ModSoundEvents.Performance perf) {
/* 78 */     if (perf == null) {
/* 79 */       this.field_70180_af.func_187227_b(PERFORMANCE, Byte.valueOf((byte)0));
/* 80 */       this.lastPerformanceTick = this.field_70173_aa;
/*    */     } else {
/*    */       
/* 83 */       this.field_70180_af.func_187227_b(PERFORMANCE, Byte.valueOf(perf.id));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean wantsTavern() {
/* 89 */     return hasTavern();
/*    */   }
/*    */   
/*    */   public int timeSincePerformance() {
/* 93 */     return this.field_70173_aa - this.lastPerformanceTick;
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_70071_h_() {
/* 98 */     super.func_70071_h_();
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityBard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */