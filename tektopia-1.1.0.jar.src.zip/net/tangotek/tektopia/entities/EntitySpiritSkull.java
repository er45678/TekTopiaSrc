/*     */ package net.tangotek.tektopia.entities;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.projectile.ProjectileHelper;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.client.ParticleDarkness;
/*     */ import net.tangotek.tektopia.client.ParticleSkull;
/*     */ 
/*     */ public class EntitySpiritSkull
/*     */   extends Entity
/*     */ {
/*     */   public enum SkullMode
/*     */   {
/*  30 */     RETURNING,
/*  31 */     PROTECTING,
/*  32 */     ATTACKING;
/*     */   }
/*     */   
/*  35 */   private double acceleration = 0.0D;
/*  36 */   private int glowTimer = 0;
/*     */   
/*     */   private boolean initialSpawn = false;
/*  39 */   private static final DataParameter<Byte> SKULL_MODE = EntityDataManager.func_187226_a(EntitySpiritSkull.class, DataSerializers.field_187191_a);
/*  40 */   private static final DataParameter<Integer> NECRO = EntityDataManager.func_187226_a(EntitySpiritSkull.class, DataSerializers.field_187192_b);
/*  41 */   private static final DataParameter<Integer> SKULL_CREATURE = EntityDataManager.func_187226_a(EntitySpiritSkull.class, DataSerializers.field_187192_b);
/*     */ 
/*     */   
/*     */   public EntitySpiritSkull(World worldIn, boolean init) {
/*  45 */     this(worldIn);
/*  46 */     this.initialSpawn = init;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntitySpiritSkull(World worldIn) {
/*  51 */     super(worldIn);
/*  52 */     func_70105_a(0.3125F, 0.3125F);
/*  53 */     func_82142_c(true);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EntitySpiritSkull(World worldIn, double x, double y, double z) {
/*  59 */     super(worldIn);
/*  60 */     func_70012_b(x, y, z, this.field_70177_z, this.field_70125_A);
/*  61 */     func_70107_b(x, y, z);
/*  62 */     func_70105_a(0.3125F, 0.3125F);
/*  63 */     func_82142_c(true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  68 */     this.field_70180_af.func_187214_a(SKULL_MODE, Byte.valueOf((byte)SkullMode.RETURNING.ordinal()));
/*  69 */     this.field_70180_af.func_187214_a(NECRO, Integer.valueOf(0));
/*  70 */     this.field_70180_af.func_187214_a(SKULL_CREATURE, Integer.valueOf(0));
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/*  75 */     super.func_70071_h_();
/*     */     
/*  77 */     boolean valid = true;
/*  78 */     if (!this.field_70170_p.func_175667_e(new BlockPos(this))) {
/*  79 */       func_70106_y();
/*  80 */       valid = false;
/*     */     } 
/*     */     
/*  83 */     SkullMode skullMode = getSkullMode();
/*  84 */     EntityNecromancer necro = getNecro();
/*  85 */     EntityCreature skullCreature = getSkullCreature();
/*     */     
/*  87 */     if (necro == null || !necro.func_70089_S()) {
/*  88 */       if (!this.field_70170_p.field_72995_K) {
/*  89 */         func_70106_y();
/*     */       }
/*  91 */       valid = false;
/*     */     }
/*  93 */     else if (skullCreature == null || !skullCreature.func_70089_S()) {
/*  94 */       if (!this.field_70170_p.field_72995_K) {
/*  95 */         necro.releaseSkull(this);
/*     */       }
/*  97 */       valid = false;
/*     */     }
/*  99 */     else if (this.field_70173_aa > 800) {
/* 100 */       necro.releaseSkull(this);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 105 */     if (valid) {
/* 106 */       if (skullMode == SkullMode.RETURNING) {
/* 107 */         if (this.field_70173_aa > 23) {
/* 108 */           Vec3d dest = necro.func_174791_d().func_72441_c(0.0D, necro.func_70047_e(), 0.0D);
/* 109 */           if (!this.field_70170_p.field_72995_K) {
/* 110 */             if (func_82150_aj()) {
/* 111 */               func_82142_c(false);
/* 112 */               func_70012_b(skullCreature.field_70165_t, skullCreature.field_70163_u + skullCreature.func_70047_e(), skullCreature.field_70161_v, 0.0F, 0.0F);
/* 113 */               func_184185_a(ModSoundEvents.deathSkullRebound, this.field_70170_p.field_73012_v.nextFloat() * 0.4F + 1.2F, this.field_70170_p.field_73012_v.nextFloat() * 0.4F + 0.8F);
/* 114 */             } else if (func_70092_e(dest.field_72450_a, dest.field_72448_b, dest.field_72449_c) < 1.0D) {
/*     */               
/* 116 */               setSkullMode(SkullMode.PROTECTING);
/* 117 */               func_184185_a(ModSoundEvents.deathSkullArrive, this.field_70170_p.field_73012_v.nextFloat() * 0.4F + 1.2F, this.field_70170_p.field_73012_v.nextFloat() * 0.4F + 0.8F);
/*     */             } 
/*     */           }
/*     */           
/* 121 */           Vec3d dir = dest.func_178788_d(func_174791_d()).func_72432_b().func_186678_a(0.3D);
/* 122 */           this.field_70159_w = dir.field_72450_a;
/* 123 */           this.field_70181_x = dir.field_72448_b;
/* 124 */           this.field_70179_y = dir.field_72449_c;
/*     */           
/* 126 */           this.field_70165_t += this.field_70159_w;
/* 127 */           this.field_70163_u += this.field_70181_x;
/* 128 */           this.field_70161_v += this.field_70179_y;
/* 129 */           ProjectileHelper.func_188803_a(this, 0.2F);
/*     */           
/* 131 */           func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
/*     */         } 
/* 133 */       } else if (skullMode == SkullMode.PROTECTING) {
/* 134 */         Vec3d origin = necro.func_174791_d().func_72441_c(0.0D, necro.func_70047_e(), 0.0D);
/* 135 */         func_70107_b(origin.field_72450_a, origin.field_72448_b, origin.field_72449_c);
/* 136 */       } else if (skullMode == SkullMode.ATTACKING) {
/* 137 */         this.field_70165_t += this.field_70159_w;
/* 138 */         this.field_70163_u += this.field_70181_x;
/* 139 */         this.field_70161_v += this.field_70179_y;
/* 140 */         ProjectileHelper.func_188803_a(this, 0.2F);
/*     */         
/* 142 */         this.field_70159_w *= this.acceleration;
/* 143 */         this.field_70181_x *= this.acceleration;
/* 144 */         this.field_70179_y *= this.acceleration;
/* 145 */         func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
/*     */       } 
/*     */       
/* 148 */       if (this.field_70170_p.field_72995_K) {
/*     */         
/* 150 */         if (skullMode != SkullMode.PROTECTING) {
/* 151 */           createDarknessParticles(5, 0.1F);
/*     */         } else {
/*     */           
/* 154 */           createDarknessParticles(2, 0.07F);
/*     */         } 
/*     */         
/* 157 */         if (skullMode == SkullMode.PROTECTING || skullMode == SkullMode.RETURNING) {
/* 158 */           necro.spawnCloud((Entity)skullCreature, 3);
/* 159 */           if (necro.func_70681_au().nextInt(4) == 0) {
/* 160 */             necro.skullParticles((Entity)skullCreature, 1);
/*     */           }
/*     */         } 
/*     */         
/* 164 */         if (this.field_70173_aa >= 1 && this.field_70173_aa <= 20 && 
/* 165 */           necro != null && skullCreature != null) {
/* 166 */           float percentFrom = (this.field_70173_aa - 1) / 20.0F;
/* 167 */           float percentTo = this.field_70173_aa / 20.0F;
/* 168 */           particleLine((Entity)necro, (Entity)skullCreature, percentFrom, percentTo, 25);
/*     */         } 
/*     */ 
/*     */         
/* 172 */         if (func_184202_aL()) {
/* 173 */           this.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, this.field_70165_t, this.field_70163_u, this.field_70161_v, this.field_70170_p.field_73012_v.nextGaussian() * 0.1D, 0.08D, this.field_70170_p.field_73012_v.nextGaussian() * 0.1D, new int[0]);
/*     */         }
/*     */         
/* 176 */         if (this.field_70173_aa > 23 && this.field_70173_aa < 27) {
/* 177 */           createSkullParticles(4);
/*     */         
/*     */         }
/*     */       }
/* 181 */       else if (this.glowTimer > 0) {
/* 182 */         this.glowTimer--;
/* 183 */         if (this.glowTimer == 0) {
/* 184 */           func_184195_f(false);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private void particleLine(Entity source, Entity target, float from, float to, int count) {
/* 194 */     Vec3d start = source.func_174791_d().func_72441_c(0.0D, source.func_70047_e(), 0.0D);
/* 195 */     Vec3d end = target.func_174791_d().func_72441_c(0.0D, target.func_70047_e(), 0.0D);
/* 196 */     Vec3d line = end.func_178788_d(start);
/*     */     
/* 198 */     for (int i = 0; i < count; i++) {
/* 199 */       Vec3d delta = line.func_186678_a(MathHelper.func_151240_a(this.field_70170_p.field_73012_v, from, to));
/* 200 */       Vec3d pos = start.func_178787_e(delta);
/* 201 */       ParticleDarkness part = new ParticleDarkness(this.field_70170_p, Minecraft.func_71410_x().func_110434_K(), pos, this.field_70181_x);
/* 202 */       part.lifeTime = this.field_70170_p.field_73012_v.nextInt(10) + 10;
/* 203 */       part.func_70538_b(0.953F, 0.173F, 0.077F);
/* 204 */       part.func_189213_a();
/* 205 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)part);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private void createDarknessParticles(int count, float radius) {
/* 212 */     for (int i = 0; i < count; i++) {
/* 213 */       double motionY = Math.random() * 0.03D + 0.01D;
/* 214 */       Vec3d pos = new Vec3d(this.field_70165_t + this.field_70146_Z.nextGaussian() * 0.1D, this.field_70163_u, this.field_70161_v + this.field_70146_Z.nextGaussian() * 0.1D);
/* 215 */       ParticleDarkness part = new ParticleDarkness(this.field_70170_p, Minecraft.func_71410_x().func_110434_K(), pos, motionY);
/* 216 */       part.radius = this.field_70170_p.field_73012_v.nextGaussian() * radius;
/* 217 */       part.radiusGrow = 0.005D;
/* 218 */       part.torque = Math.random() * 0.04D - 0.02D;
/* 219 */       part.lifeTime = this.field_70170_p.field_73012_v.nextInt(15) + 20;
/* 220 */       part.func_189213_a();
/* 221 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)part);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private void createSkullParticles(int count) {
/* 227 */     for (int i = 0; i < count; i++) {
/* 228 */       double motionY = Math.random() * 0.03D + 0.01D;
/* 229 */       Vec3d pos = new Vec3d(this.field_70165_t + this.field_70146_Z.nextGaussian() * 0.5D, this.field_70163_u + this.field_70146_Z.nextGaussian(), this.field_70161_v + this.field_70146_Z.nextGaussian() * 0.5D);
/* 230 */       ParticleSkull part = new ParticleSkull(this.field_70170_p, Minecraft.func_71410_x().func_110434_K(), pos, motionY);
/* 231 */       part.radius = this.field_70170_p.field_73012_v.nextGaussian() * 0.1D;
/* 232 */       part.radiusGrow = 0.005D;
/* 233 */       part.torque = Math.random() * 0.04D - 0.02D;
/* 234 */       part.lifeTime = this.field_70170_p.field_73012_v.nextInt(15) + 20;
/* 235 */       part.func_189213_a();
/* 236 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)part);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityNecromancer getNecro() {
/* 243 */     Integer entityId = (Integer)this.field_70180_af.func_187225_a(NECRO);
/* 244 */     if (entityId.intValue() > 0) {
/* 245 */       Entity e = this.field_70170_p.func_73045_a(entityId.intValue());
/* 246 */       if (e instanceof EntityNecromancer) {
/* 247 */         return (EntityNecromancer)e;
/*     */       }
/*     */     } 
/* 250 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNecro(EntityNecromancer necro) {
/* 255 */     this.field_70180_af.func_187227_b(NECRO, Integer.valueOf((necro == null) ? 0 : necro.func_145782_y()));
/*     */   }
/*     */   
/*     */   public void setSkullCreature(EntityCreature creature) {
/* 259 */     this.field_70180_af.func_187227_b(SKULL_CREATURE, Integer.valueOf((creature == null) ? 0 : creature.func_145782_y()));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityCreature getSkullCreature() {
/* 265 */     Integer entityId = (Integer)this.field_70180_af.func_187225_a(SKULL_CREATURE);
/* 266 */     if (entityId.intValue() > 0) {
/* 267 */       Entity e = this.field_70170_p.func_73045_a(entityId.intValue());
/* 268 */       if (e instanceof EntityCreature && e.func_70089_S()) {
/* 269 */         return (EntityCreature)e;
/*     */       }
/*     */     } 
/* 272 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SkullMode getSkullMode() {
/* 277 */     int index = ((Byte)this.field_70180_af.func_187225_a(SKULL_MODE)).byteValue();
/* 278 */     return SkullMode.values()[index];
/*     */   }
/*     */   
/*     */   public void setSkullMode(SkullMode mode) {
/* 282 */     this.field_70159_w = 0.0D;
/* 283 */     this.field_70181_x = 0.0D;
/* 284 */     this.field_70179_y = 0.0D;
/* 285 */     this.acceleration = 0.0D;
/* 286 */     this.field_70180_af.func_187227_b(SKULL_MODE, Byte.valueOf((byte)mode.ordinal()));
/*     */     
/* 288 */     if (mode == SkullMode.ATTACKING)
/* 289 */       this.acceleration = 1.02D; 
/*     */   }
/*     */   
/*     */   public float getSpinRadius() {
/* 293 */     return 1.3F + (float)Math.abs(func_110124_au().getLeastSignificantBits() % 70L) / 100.0F;
/*     */   }
/*     */   
/*     */   public float getSpinSpeed() {
/* 297 */     float speed = 4.0F + (float)(Math.abs(func_110124_au().getLeastSignificantBits()) % 6L);
/* 298 */     if (func_110124_au().getLeastSignificantBits() % 2L == 0L) {
/* 299 */       speed = -speed;
/*     */     }
/* 301 */     return speed;
/*     */   }
/*     */   
/*     */   public float getSpinAxis() {
/* 305 */     return (float)Math.abs(func_110124_au().getLeastSignificantBits() % 6L) / 10.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_70112_a(double distance) {
/* 324 */     double d0 = func_174813_aQ().func_72320_b() * 4.0D;
/*     */     
/* 326 */     if (Double.isNaN(d0))
/*     */     {
/* 328 */       d0 = 4.0D;
/*     */     }
/*     */     
/* 331 */     d0 *= 64.0D;
/* 332 */     return (distance < d0 * d0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70037_a(NBTTagCompound compound) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70014_b(NBTTagCompound compound) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70067_L() {
/* 351 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70097_a(DamageSource source, float amount) {
/* 359 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntitySpiritSkull.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */