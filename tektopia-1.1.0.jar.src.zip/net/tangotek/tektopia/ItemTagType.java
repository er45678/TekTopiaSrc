/*    */ package net.tangotek.tektopia;
/*    */ 
/*    */ public enum ItemTagType {
/*  4 */   VILLAGER("villager", "Â§2"),
/*  5 */   STRUCTURE("struct", "");
/*    */   
/*    */   public final String tag;
/*    */   public final String colorPrefix;
/*    */   
/*    */   ItemTagType(String tag, String colorPrefix) {
/* 11 */     this.tag = tag;
/* 12 */     this.colorPrefix = colorPrefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\ItemTagType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */