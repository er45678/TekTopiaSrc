/*    */ package net.tangotek.tektopia.generation;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.structure.StructureBoundingBox;
/*    */ import net.minecraft.world.gen.structure.StructureVillagePieces;
/*    */ import net.tangotek.tektopia.TekVillager;
/*    */ import net.tangotek.tektopia.structures.VillageStructureType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TekStorageHall
/*    */   extends StructureVillagePieces.House3
/*    */ {
/*    */   public TekStorageHall(StructureVillagePieces.Start start, int type, Random rand, StructureBoundingBox bbox, EnumFacing facing) {
/* 20 */     super(start, type, rand, bbox, facing);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TekStorageHall() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_74875_a(World worldIn, Random randomIn, StructureBoundingBox structureBoundingBoxIn) {
/* 30 */     boolean result = super.func_74875_a(worldIn, randomIn, structureBoundingBoxIn);
/* 31 */     if (!this.field_189929_i) {
/* 32 */       func_175811_a(worldIn, Blocks.field_150462_ai.func_176223_P(), 1, 1, 4, structureBoundingBoxIn);
/* 33 */       func_189926_a(worldIn, EnumFacing.WEST, 7, 1, 6, structureBoundingBoxIn);
/*    */       
/* 35 */       func_186167_a(worldIn, structureBoundingBoxIn, randomIn, 4, 1, 9, TekVillager.VILLAGE_STORAGE);
/* 36 */       func_186167_a(worldIn, structureBoundingBoxIn, randomIn, 6, 1, 9, TekVillager.VILLAGE_STORAGE);
/* 37 */       func_186167_a(worldIn, structureBoundingBoxIn, randomIn, 2, 1, 4, TekVillager.VILLAGE_STORAGE);
/*    */     } 
/* 39 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_74893_a(World worldIn, StructureBoundingBox structurebb, int x, int y, int z, int count) {}
/*    */ 
/*    */   
/*    */   public BlockPos getBlockPos(int x, int y, int z) {
/* 48 */     return new BlockPos(func_74865_a(x, z), func_74862_a(y), func_74873_b(x, z));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void func_189927_a(World w, StructureBoundingBox bb, Random rand, int x, int y, int z, EnumFacing facing) {
/* 53 */     super.func_189927_a(w, bb, rand, x, y, z, facing);
/* 54 */     TekStructureVillagePieces.addStructureFrame(w, bb, getBlockPos(x, y, z), VillageStructureType.STORAGE);
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\generation\TekStorageHall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */