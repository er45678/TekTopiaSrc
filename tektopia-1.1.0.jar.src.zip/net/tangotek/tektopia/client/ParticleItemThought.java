/*    */ package net.tangotek.tektopia.client;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.particle.Particle;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class ParticleItemThought
/*    */   extends Particle
/*    */ {
/*    */   private final int lifeTime;
/*    */   private final Entity ent;
/*    */   
/*    */   public ParticleItemThought(World worldIn, Entity ent, Item item) {
/* 27 */     super(worldIn, ent.field_70165_t, (ent.func_174813_aQ()).field_72337_e + 0.8D, ent.field_70161_v, 0.0D, 0.0D, 0.0D);
/* 28 */     func_187117_a(Minecraft.func_71410_x().func_175599_af().func_175037_a().func_178082_a(item));
/* 29 */     this.ent = ent;
/* 30 */     this.lifeTime = 40;
/* 31 */     this.field_70552_h = 1.0F;
/* 32 */     this.field_70553_i = 1.0F;
/* 33 */     this.field_70551_j = 1.0F;
/* 34 */     this.field_187129_i = 0.0D;
/* 35 */     this.field_187130_j = 0.013D;
/* 36 */     this.field_187131_k = 0.0D;
/* 37 */     this.field_70545_g = 0.0F;
/* 38 */     this.field_70547_e = 40;
/* 39 */     this.field_70544_f = 0.2F;
/* 40 */     func_70541_f(0.15F);
/* 41 */     this.field_190017_n = false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_70537_b() {
/* 50 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_189213_a() {
/* 57 */     this.field_82339_as -= 0.02F;
/* 58 */     super.func_189213_a();
/*    */     
/* 60 */     this.field_187123_c = this.field_187126_f;
/* 61 */     this.field_187124_d = this.field_187127_g;
/* 62 */     this.field_187125_e = this.field_187128_h;
/* 63 */     func_187110_a(this.ent.field_70165_t - this.field_187123_c, this.field_187130_j, this.ent.field_70161_v - this.field_187125_e);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_180434_a(BufferBuilder buffer, Entity entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
/* 71 */     GlStateManager.func_179094_E();
/*    */     
/* 73 */     float f = this.field_187119_C.func_94209_e();
/* 74 */     float f1 = this.field_187119_C.func_94212_f();
/* 75 */     float f2 = this.field_187119_C.func_94206_g();
/* 76 */     float f3 = this.field_187119_C.func_94210_h();
/* 77 */     float f4 = 0.5F;
/* 78 */     float f5 = (float)(this.field_187123_c + (this.field_187126_f - this.field_187123_c) * partialTicks - field_70556_an);
/* 79 */     float f6 = (float)(this.field_187124_d + (this.field_187127_g - this.field_187124_d) * partialTicks - field_70554_ao);
/* 80 */     float f7 = (float)(this.field_187125_e + (this.field_187128_h - this.field_187125_e) * partialTicks - field_70555_ap);
/* 81 */     int i = func_189214_a(partialTicks);
/* 82 */     int j = i >> 16 & 0xFFFF;
/* 83 */     int k = i & 0xFFFF;
/* 84 */     float scale = 0.3F;
/* 85 */     buffer.func_181662_b((f5 - rotationX * scale - rotationXY * scale), (f6 - rotationZ * scale), (f7 - rotationYZ * scale - rotationXZ * scale)).func_187315_a(f1, f3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 1.0F).func_187314_a(j, k).func_181675_d();
/* 86 */     buffer.func_181662_b((f5 - rotationX * scale + rotationXY * scale), (f6 + rotationZ * scale), (f7 - rotationYZ * scale + rotationXZ * scale)).func_187315_a(f1, f2).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 1.0F).func_187314_a(j, k).func_181675_d();
/* 87 */     buffer.func_181662_b((f5 + rotationX * scale + rotationXY * scale), (f6 + rotationZ * scale), (f7 + rotationYZ * scale + rotationXZ * scale)).func_187315_a(f, f2).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 1.0F).func_187314_a(j, k).func_181675_d();
/* 88 */     buffer.func_181662_b((f5 + rotationX * scale - rotationXY * scale), (f6 - rotationZ * scale), (f7 + rotationYZ * scale - rotationXZ * scale)).func_187315_a(f, f3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 1.0F).func_187314_a(j, k).func_181675_d();
/* 89 */     GlStateManager.func_179121_F();
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\client\ParticleItemThought.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */