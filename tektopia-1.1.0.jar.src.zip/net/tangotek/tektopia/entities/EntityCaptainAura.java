/*    */ package net.tangotek.tektopia.entities;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityAreaEffectCloud;
/*    */ import net.minecraft.init.MobEffects;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.EnumParticleTypes;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityCaptainAura
/*    */   extends EntityAreaEffectCloud
/*    */ {
/* 22 */   private float radius = 3.0F;
/* 23 */   private final float RADIUS_PER_TICK = 0.5F;
/*    */ 
/*    */   
/*    */   public EntityCaptainAura(World worldIn) {
/* 27 */     super(worldIn);
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityCaptainAura(World worldIn, double x, double y, double z) {
/* 32 */     super(worldIn, x, y, z);
/* 33 */     func_184491_a(EnumParticleTypes.FIREWORKS_SPARK);
/* 34 */     func_184483_a(this.radius);
/* 35 */     func_184487_c(0.5F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_70071_h_() {
/* 41 */     this.radius += 0.5F;
/* 42 */     if (this.field_70170_p.field_72995_K) {
/* 43 */       for (int i = 0; i < 10; i++) {
/* 44 */         perimeterParticle();
/*    */       }
/*    */     } else {
/*    */       
/* 48 */       if (this.field_70173_aa >= func_184489_o()) {
/*    */         
/* 50 */         func_70106_y();
/*    */         
/*    */         return;
/*    */       } 
/* 54 */       double radiusSq = (this.radius * this.radius);
/* 55 */       List<EntityVillagerTek> villagerList = this.field_70170_p.func_72872_a(EntityVillagerTek.class, func_174813_aQ());
/*    */       
/* 57 */       villagerList.stream().filter(g -> (g.func_70068_e((Entity)this) < radiusSq)).forEach(g -> g.func_70690_d(new PotionEffect(MobEffects.field_76429_m, 100)));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   private void perimeterParticle() {
/* 64 */     double motionY = Math.random() * 0.01D + 0.01D;
/* 65 */     float f1 = this.field_70170_p.field_73012_v.nextFloat() * 6.2831855F;
/* 66 */     float xOffset = MathHelper.func_76134_b(f1) * this.radius;
/* 67 */     float zOffset = MathHelper.func_76126_a(f1) * this.radius;
/*    */     
/* 69 */     Vec3d pos = new Vec3d(this.field_70165_t + xOffset, this.field_70163_u, this.field_70161_v + zOffset);
/* 70 */     this.field_70170_p.func_175688_a(EnumParticleTypes.FIREWORKS_SPARK, pos.field_72450_a, pos.field_72448_b, pos.field_72449_c, 0.0D, motionY, 0.0D, new int[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityCaptainAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */