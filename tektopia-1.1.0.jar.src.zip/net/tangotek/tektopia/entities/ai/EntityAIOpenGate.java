/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockFenceGate;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.pathfinding.Path;
/*     */ import net.minecraft.pathfinding.PathPoint;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.pathing.PathNavigateVillager2;
/*     */ 
/*     */ public class EntityAIOpenGate extends EntityAIBase {
/*     */   private EntityVillagerTek villager;
/*  18 */   protected BlockPos gatePosition = BlockPos.field_177992_a;
/*     */   
/*     */   protected BlockFenceGate gateBlock;
/*     */   
/*     */   boolean hasStoppedDoorInteraction;
/*     */   float entityPositionX;
/*     */   float entityPositionZ;
/*     */   int closeDoorTemporisation;
/*     */   
/*     */   public EntityAIOpenGate(EntityVillagerTek v) {
/*  28 */     this.villager = v;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  33 */     if (!this.villager.field_70123_F)
/*     */     {
/*  35 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  39 */     PathNavigateVillager2 pathNavigate = (PathNavigateVillager2)this.villager.func_70661_as();
/*  40 */     Path path = pathNavigate.func_75505_d();
/*     */     
/*  42 */     if (path != null && !path.func_75879_b() && pathNavigate.getEnterDoors()) {
/*     */       
/*  44 */       for (int i = 0; i < Math.min(path.func_75873_e() + 2, path.func_75874_d()); i++) {
/*     */         
/*  46 */         PathPoint pathpoint = path.func_75877_a(i);
/*  47 */         this.gatePosition = new BlockPos(pathpoint.field_75839_a, pathpoint.field_75837_b + 1, pathpoint.field_75838_c);
/*     */         
/*  49 */         if (this.villager.func_70092_e(this.gatePosition.func_177958_n(), this.villager.field_70163_u, this.gatePosition.func_177952_p()) <= 2.25D) {
/*     */           
/*  51 */           this.gateBlock = getBlockGate(this.gatePosition);
/*     */           
/*  53 */           if (this.gateBlock != null)
/*     */           {
/*  55 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  60 */       this.gatePosition = new BlockPos((Entity)this.villager);
/*  61 */       this.gateBlock = getBlockGate(this.gatePosition);
/*  62 */       return (this.gateBlock != null);
/*     */     } 
/*     */ 
/*     */     
/*  66 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  75 */     return (this.closeDoorTemporisation > 0 && !this.hasStoppedDoorInteraction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  83 */     this.closeDoorTemporisation = 20;
/*  84 */     toggleGate(this.gatePosition, true);
/*     */     
/*  86 */     this.hasStoppedDoorInteraction = false;
/*  87 */     this.entityPositionX = (float)((this.gatePosition.func_177958_n() + 0.5F) - this.villager.field_70165_t);
/*  88 */     this.entityPositionZ = (float)((this.gatePosition.func_177952_p() + 0.5F) - this.villager.field_70161_v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  96 */     float f = (float)((this.gatePosition.func_177958_n() + 0.5F) - this.villager.field_70165_t);
/*  97 */     float f1 = (float)((this.gatePosition.func_177952_p() + 0.5F) - this.villager.field_70161_v);
/*  98 */     float f2 = this.entityPositionX * f + this.entityPositionZ * f1;
/*     */     
/* 100 */     if (f2 < 0.0F)
/*     */     {
/* 102 */       this.hasStoppedDoorInteraction = true;
/*     */     }
/*     */     
/* 105 */     this.closeDoorTemporisation--;
/* 106 */     super.func_75246_d();
/*     */   }
/*     */ 
/*     */   
/*     */   private BlockFenceGate getBlockGate(BlockPos pos) {
/* 111 */     IBlockState iblockstate = this.villager.field_70170_p.func_180495_p(pos);
/* 112 */     Block block = iblockstate.func_177230_c();
/* 113 */     return (block instanceof BlockFenceGate) ? (BlockFenceGate)block : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 118 */     toggleGate(this.gatePosition, false);
/*     */   }
/*     */   
/*     */   private void toggleGate(BlockPos gatePosition, boolean open) {
/* 122 */     IBlockState state = this.villager.field_70170_p.func_180495_p(gatePosition);
/* 123 */     if (getBlockGate(gatePosition) != null && (
/* 124 */       (Boolean)state.func_177229_b((IProperty)BlockFenceGate.field_176466_a)).booleanValue() != open) {
/* 125 */       state = state.func_177226_a((IProperty)BlockFenceGate.field_176466_a, Boolean.valueOf(open));
/* 126 */       this.villager.field_70170_p.func_180501_a(gatePosition, state, 10);
/* 127 */       this.villager.field_70170_p.func_180498_a((EntityPlayer)null, ((Boolean)state.func_177229_b((IProperty)BlockFenceGate.field_176466_a)).booleanValue() ? 1008 : 1014, gatePosition, 0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIOpenGate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */