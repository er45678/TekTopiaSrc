/*    */ package net.tangotek.tektopia.generation;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.BlockBed;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.structure.StructureBoundingBox;
/*    */ import net.minecraft.world.gen.structure.StructureVillagePieces;
/*    */ import net.tangotek.tektopia.structures.VillageStructureType;
/*    */ 
/*    */ public class TekHouse2 extends StructureVillagePieces.WoodHut {
/*    */   private int villagersSpawned;
/*    */   
/*    */   public TekHouse2(StructureVillagePieces.Start start, int type, Random rand, StructureBoundingBox bbox, EnumFacing facing) {
/* 19 */     super(start, type, rand, bbox, facing);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TekHouse2() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_74875_a(World worldIn, Random randomIn, StructureBoundingBox structureBoundingBoxIn) {
/* 29 */     boolean result = super.func_74875_a(worldIn, randomIn, structureBoundingBoxIn);
/* 30 */     if (!this.field_189929_i) {
/* 31 */       placeBedPiece(worldIn, structureBoundingBoxIn, 2, 1, 2, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
/* 32 */       placeBedPiece(worldIn, structureBoundingBoxIn, 2, 1, 3, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
/*    */       
/* 34 */       func_189926_a(worldIn, EnumFacing.SOUTH, 1, 1, 3, structureBoundingBoxIn);
/*    */     } 
/* 36 */     return result;
/*    */   }
/*    */   
/*    */   public BlockPos getBlockPos(int x, int y, int z) {
/* 40 */     return new BlockPos(func_74865_a(x, z), func_74862_a(y), func_74873_b(x, z));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void func_189927_a(World w, StructureBoundingBox bb, Random rand, int x, int y, int z, EnumFacing facing) {
/* 45 */     super.func_189927_a(w, bb, rand, x, y, z, facing);
/* 46 */     TekStructureVillagePieces.addStructureFrame(w, bb, getBlockPos(x, y, z), VillageStructureType.HOME2);
/*    */   }
/*    */ 
/*    */   
/*    */   private void placeBedPiece(World worldIn, StructureBoundingBox bbox, int x, int y, int z, EnumFacing facing, BlockBed.EnumPartType partType) {
/* 51 */     IBlockState bedState = Blocks.field_150324_C.func_176223_P().func_177226_a((IProperty)BlockBed.field_176471_b, Boolean.valueOf(false)).func_177226_a((IProperty)BlockBed.field_185512_D, (Comparable)facing);
/* 52 */     func_175811_a(worldIn, bedState.func_177226_a((IProperty)BlockBed.field_176472_a, (Comparable)partType), x, y, z, bbox);
/* 53 */     func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), x, y + 1, z, bbox);
/*    */   }
/*    */   
/*    */   protected void func_74893_a(World worldIn, StructureBoundingBox structurebb, int x, int y, int z, int count) {}
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\generation\TekHouse2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */