/*    */ package net.tangotek.tektopia;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.network.datasync.DataParameter;
/*    */ import net.minecraft.network.datasync.DataSerializer;
/*    */ import net.minecraft.network.datasync.DataSerializers;
/*    */ 
/*    */ 
/*    */ public class TekDataSerializers
/*    */ {
/* 14 */   public static final DataSerializer<List<Integer>> INT_LIST = new DataSerializer<List<Integer>>()
/*    */     {
/*    */       public void write(PacketBuffer buf, List<Integer> list)
/*    */       {
/* 18 */         buf.func_150787_b(list.size());
/* 19 */         list.stream().forEach(i -> buf.func_150787_b(i.intValue()));
/*    */       }
/*    */       
/*    */       public List<Integer> read(PacketBuffer buf) throws IOException {
/* 23 */         int i = buf.func_150792_a();
/* 24 */         List<Integer> outList = new ArrayList<>();
/* 25 */         for (int j = 0; j < i; j++) {
/* 26 */           outList.add(Integer.valueOf(buf.func_150792_a()));
/*    */         }
/* 28 */         return outList;
/*    */       }
/*    */       
/*    */       public DataParameter<List<Integer>> func_187161_a(int id) {
/* 32 */         return new DataParameter(id, this);
/*    */       }
/*    */       
/*    */       public List<Integer> copyValue(List<Integer> value) {
/* 36 */         return value;
/*    */       }
/*    */     };
/*    */   
/*    */   static {
/* 41 */     DataSerializers.func_187189_a(INT_LIST);
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\TekDataSerializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */