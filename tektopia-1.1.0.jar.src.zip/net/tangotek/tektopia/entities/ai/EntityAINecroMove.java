/*    */ package net.tangotek.tektopia.entities.ai;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.passive.EntityAnimal;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.Vec3i;
/*    */ import net.tangotek.tektopia.entities.EntityNecromancer;
/*    */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*    */ import net.tangotek.tektopia.structures.VillageStructure;
/*    */ import net.tangotek.tektopia.structures.VillageStructureType;
/*    */ 
/*    */ public class EntityAINecroMove extends EntityAIMoveToBlock {
/*    */   protected final EntityNecromancer necro;
/* 15 */   private int failedPath = 0;
/*    */   
/*    */   public EntityAINecroMove(EntityNecromancer n) {
/* 18 */     super((EntityVillageNavigator)n);
/* 19 */     this.necro = n;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 24 */     if (this.navigator.isAITick() && this.navigator.hasVillage() && !this.navigator.func_70781_l()) {
/* 25 */       return super.func_75250_a();
/*    */     }
/* 27 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BlockPos getDestinationBlock() {
/* 33 */     if (this.necro.isAngry() && this.necro.func_70681_au().nextInt(3) == 0) {
/* 34 */       List<VillageStructure> animalePens = this.necro.getVillage().getStructures(new VillageStructureType[] { VillageStructureType.COW_PEN, VillageStructureType.SHEEP_PEN, VillageStructureType.CHICKEN_COOP, VillageStructureType.PIG_PEN });
/* 35 */       if (!animalePens.isEmpty()) {
/*    */         
/* 37 */         animalePens.removeIf(p -> (p.getEntitiesInside(EntityAnimal.class).size() <= 0));
/* 38 */         VillageStructure closestPen = animalePens.stream().min(Comparator.comparing(p -> Double.valueOf(p.getDoor().func_177951_i((Vec3i)this.navigator.func_180425_c())))).orElse(null);
/* 39 */         if (closestPen != null) {
/* 40 */           return closestPen.getDoor();
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 45 */     return this.navigator.getVillage().getLastVillagerPos();
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_75249_e() {
/* 50 */     super.func_75249_e();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   void updateMovementMode() {}
/*    */ 
/*    */ 
/*    */   
/*    */   protected void onPathFailed(BlockPos pos) {
/* 60 */     this.failedPath++;
/* 61 */     if (this.failedPath > 50) {
/* 62 */       this.necro.debugOut("Killed Necro. Too many failed pathfindings");
/* 63 */       this.necro.func_70106_y();
/*    */     } 
/*    */     
/* 66 */     super.onPathFailed(pos);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isNearWalkPos() {
/* 71 */     return (this.necro.func_180425_c().func_177951_i((Vec3i)this.destinationPos) < 4.0D);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void onArrival() {
/* 77 */     super.onArrival();
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_75251_c() {
/* 82 */     super.func_75251_c();
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAINecroMove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */