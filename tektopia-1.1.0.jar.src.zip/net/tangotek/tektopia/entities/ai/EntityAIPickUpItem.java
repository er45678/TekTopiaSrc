/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import com.google.common.base.Predicate;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ 
/*     */ public class EntityAIPickUpItem
/*     */   extends EntityAIMoveToBlock
/*     */ {
/*     */   protected final EntityVillagerTek villager;
/*     */   private List<PickUpData> pickUps;
/*     */   protected EntityItem pickUpItem;
/*     */   private final int chance;
/*     */   
/*     */   public static class PickUpData {
/*     */     public final int quantity;
/*     */     public final ItemStack itemStack;
/*     */     public final String aiFilter;
/*     */     
/*     */     public PickUpData(ItemStack itemStack, int quantity, String aiFilter) {
/*  27 */       this.itemStack = itemStack;
/*  28 */       this.quantity = quantity;
/*  29 */       this.aiFilter = aiFilter;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityAIPickUpItem(EntityVillagerTek v, List<PickUpData> pickUpCounts, int chance) {
/*  36 */     super((EntityVillageNavigator)v);
/*  37 */     this.villager = v;
/*  38 */     this.pickUps = pickUpCounts;
/*  39 */     this.chance = chance;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  44 */     if (this.villager.isAITick() && this.navigator.hasVillage() && this.villager.isWorkTime() && 
/*  45 */       this.villager.func_70681_au().nextInt(this.chance) == 0) {
/*  46 */       return super.func_75250_a();
/*     */     }
/*     */     
/*  49 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockPos getDestinationBlock() {
/*  54 */     List<EntityItem> entityItems = this.villager.field_70170_p.func_175647_a(EntityItem.class, this.villager.func_174813_aQ().func_72314_b(20.0D, 10.0D, 20.0D), shouldPickUp(this.villager));
/*  55 */     this.pickUpItem = entityItems.stream().min(Comparator.comparing(e -> Double.valueOf(e.func_70068_e((Entity)this.villager)))).orElse(null);
/*  56 */     if (this.pickUpItem != null) {
/*  57 */       return this.pickUpItem.func_180425_c();
/*     */     }
/*     */     
/*  60 */     return null;
/*     */   }
/*     */   
/*     */   private Predicate<EntityItem> shouldPickUp(EntityVillagerTek villager) {
/*  64 */     return e -> {
/*     */         if (this.villager.getVillage().getPathingGraph().isInGraph(e.func_180425_c())) {
/*     */           for (PickUpData pickUp : this.pickUps) {
/*     */             if (villager.isAIFilterEnabled(pickUp.aiFilter) && e.func_92059_d().func_77969_a(pickUp.itemStack)) {
/*     */               int itemCount = villager.getInventory().getItemCount(());
/*     */               if (itemCount < pickUp.quantity) {
/*     */                 return true;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         }
/*     */         return false;
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BlockPos findWalkPos() {
/*  83 */     return this.destinationPos;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  88 */     super.func_75249_e();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  93 */     if (this.pickUpItem.func_70089_S()) {
/*  94 */       return super.func_75253_b();
/*     */     }
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   void updateMovementMode() {
/* 101 */     this.villager.setMovementMode(this.villager.getDefaultMovement());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onArrival() {
/* 106 */     this.villager.pickupItems(4);
/* 107 */     super.onArrival();
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 112 */     this.pickUpItem = null;
/* 113 */     super.func_75251_c();
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIPickUpItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */