/*    */ package net.tangotek.tektopia.blockfinder;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.tangotek.tektopia.Village;
/*    */ 
/*    */ public class SugarCaneScanner
/*    */   extends BlockScanner
/*    */ {
/*    */   public SugarCaneScanner(Village v, int scansPerTick) {
/* 14 */     super((Block)Blocks.field_150436_aH, v, scansPerTick);
/*    */   }
/*    */ 
/*    */   
/*    */   public static BlockPos getCaneStalk(World w, BlockPos bp) {
/* 19 */     if (isCane(w.func_180495_p(bp))) {
/*    */       
/*    */       do {
/* 22 */         bp = bp.func_177977_b();
/* 23 */       } while (isCane(w.func_180495_p(bp)));
/*    */ 
/*    */       
/* 26 */       Block downBlock = w.func_180495_p(bp.func_177977_b()).func_177230_c();
/* 27 */       if (downBlock == Blocks.field_150426_aN) {
/* 28 */         return null;
/*    */       }
/*    */ 
/*    */       
/* 32 */       if (isCane(w.func_180495_p(bp.func_177981_b(2)))) {
/* 33 */         return bp.func_177984_a();
/*    */       }
/*    */     } 
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public BlockPos testBlock(World w, BlockPos bp) {
/* 41 */     return getCaneStalk(w, bp);
/*    */   }
/*    */ 
/*    */   
/*    */   public void scanNearby(BlockPos bp) {
/* 46 */     for (BlockPos scanPos : BlockPos.func_191532_a(bp.func_177958_n() - 2, bp.func_177956_o(), bp.func_177952_p() - 2, bp.func_177958_n() + 2, bp.func_177956_o(), bp.func_177952_p() + 2))
/*    */     {
/* 48 */       scanBlock(scanPos);
/*    */     }
/*    */   }
/*    */   
/*    */   public static boolean isCane(IBlockState blockState) {
/* 53 */     return (blockState.func_177230_c() == Blocks.field_150436_aH);
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\blockfinder\SugarCaneScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */