/*     */ package net.tangotek.tektopia.entities;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IMerchant;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraft.village.MerchantRecipe;
/*     */ import net.minecraft.village.MerchantRecipeList;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.VillagerRole;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIWanderStructure;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ import net.tangotek.tektopia.tickjob.TickJob;
/*     */ 
/*     */ public abstract class EntityVendor
/*     */   extends EntityVillagerTek
/*     */   implements IMerchant {
/*     */   @Nullable
/*     */   protected EntityPlayer buyingPlayer;
/*     */   @Nullable
/*     */   protected MerchantRecipeList buyingList;
/*     */   
/*     */   public EntityVendor(World worldIn, int roleMask) {
/*  38 */     super(worldIn, (ProfessionType)null, roleMask | VillagerRole.VENDOR.value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupServerJobs() {
/*  43 */     super.setupServerJobs();
/*     */     
/*  45 */     addJob(new TickJob(200, 200, true, () -> {
/*     */             if (getCurrentStructure() == null) {
/*     */               func_70106_y();
/*     */             }
/*     */           }));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMale() {
/*  54 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initEntityAIBase() {}
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/*  63 */     super.func_184651_r();
/*     */     
/*  65 */     addTask(50, (EntityAIBase)new EntityAIWanderStructure(this, p -> p.getCurrentStructure(), p -> (p.func_70681_au().nextInt(5) == 0), 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ItemStack createEmerald(int qty) {
/*  72 */     return new ItemStack(Items.field_151166_bC, qty);
/*     */   }
/*     */   
/*     */   protected MerchantRecipe createMerchantRecipe(ItemStack item, int emeraldCost) {
/*  76 */     if (emeraldCost <= 64)
/*  77 */       return new MerchantRecipe(createEmerald(emeraldCost), ItemStack.field_190927_a, item, 0, 99999); 
/*  78 */     if (emeraldCost % 9 == 0) {
/*  79 */       return new MerchantRecipe(new ItemStack(Item.func_150898_a(Blocks.field_150475_bE), emeraldCost / 9), ItemStack.field_190927_a, item, 0, 99999);
/*     */     }
/*  81 */     return new MerchantRecipe(new ItemStack(Item.func_150898_a(Blocks.field_150475_bE), emeraldCost / 9), createEmerald(emeraldCost % 9), item, 0, 99999);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canConvertProfession(ProfessionType pt) {
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addVillagerPosition() {}
/*     */ 
/*     */   
/*     */   public void func_70932_a_(@Nullable EntityPlayer player) {
/*  95 */     this.buyingPlayer = player;
/*  96 */     this.buyingList = null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityPlayer func_70931_l_() {
/* 102 */     return this.buyingPlayer;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTrading() {
/* 107 */     return (this.buyingPlayer != null);
/*     */   }
/*     */   
/*     */   public boolean isSleepingTime() {
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void bedCheck() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHunger() {
/* 121 */     return getMaxHunger();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MerchantRecipeList func_70934_b(EntityPlayer player) {
/* 127 */     if (this.buyingList == null)
/*     */     {
/* 129 */       populateBuyingList();
/*     */     }
/*     */     
/* 132 */     return this.buyingList;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_184645_a(EntityPlayer player, EnumHand hand) {
/* 137 */     ItemStack itemstack = player.func_184586_b(hand);
/* 138 */     boolean flag = (itemstack.func_77973_b() == Items.field_151057_cb);
/*     */     
/* 140 */     if (flag) {
/*     */       
/* 142 */       itemstack.func_111282_a(player, (EntityLivingBase)this, hand);
/*     */     }
/* 144 */     else if (func_70089_S() && !isTrading() && !func_70631_g_() && !player.func_70093_af()) {
/*     */       
/* 146 */       if (this.buyingList == null)
/*     */       {
/* 148 */         populateBuyingList();
/*     */       }
/*     */       
/* 151 */       if (this.buyingList != null) {
/* 152 */         if (!this.field_70170_p.field_72995_K && !this.buyingList.isEmpty()) {
/* 153 */           func_70932_a_(player);
/* 154 */           func_70661_as().func_75499_g();
/* 155 */           player.func_180472_a(this);
/* 156 */         } else if (this.buyingList.isEmpty()) {
/* 157 */           return super.func_184645_a(player, hand);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 162 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_70930_a(@Nullable MerchantRecipeList recipeList) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public World func_190670_t_() {
/* 174 */     return this.field_70170_p;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70933_a(MerchantRecipe recipe) {
/* 179 */     recipe.func_77399_f();
/* 180 */     this.field_70757_a = -func_70627_aG();
/* 181 */     func_184185_a(SoundEvents.field_187915_go, func_70599_aP(), func_70647_i());
/* 182 */     setHappy(getMaxHappy());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_110297_a_(ItemStack stack) {
/* 188 */     if (!this.field_70170_p.field_72995_K && this.field_70757_a > -func_70627_aG() + 20) {
/*     */       
/* 190 */       this.field_70757_a = -func_70627_aG();
/* 191 */       func_184185_a(stack.func_190926_b() ? SoundEvents.field_187913_gm : SoundEvents.field_187915_go, func_70599_aP(), func_70647_i());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITextComponent func_145748_c_() {
/* 206 */     TextComponentTranslation textComponentTranslation = new TextComponentTranslation(getTranslationKey(), new Object[0]);
/* 207 */     textComponentTranslation.func_150256_b().func_150209_a(func_174823_aP());
/* 208 */     textComponentTranslation.func_150256_b().func_179989_a(func_189512_bd());
/*     */     
/* 210 */     return (ITextComponent)textComponentTranslation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockPos func_190671_u_() {
/* 217 */     return new BlockPos((Entity)this);
/*     */   }
/*     */   
/*     */   protected abstract void populateBuyingList();
/*     */   
/*     */   protected abstract String getTranslationKey();
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityVendor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */