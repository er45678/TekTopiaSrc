/*     */ package net.tangotek.tektopia.entities;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.TekVillager;
/*     */ import net.tangotek.tektopia.VillagerRole;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIFeedAnimal;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIHarvestAnimal;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIReturnLostAnimal;
/*     */ import net.tangotek.tektopia.storage.ItemDesire;
/*     */ import net.tangotek.tektopia.structures.VillageStructureChickenCoop;
/*     */ import net.tangotek.tektopia.structures.VillageStructureCowPen;
/*     */ import net.tangotek.tektopia.structures.VillageStructurePigPen;
/*     */ import net.tangotek.tektopia.structures.VillageStructureSheepPen;
/*     */ import net.tangotek.tektopia.structures.VillageStructureType;
/*     */ 
/*     */ public class EntityRancher extends EntityVillagerTek {
/*  27 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityRancher.class);
/*     */   
/*  29 */   private static final DataParameter<Boolean> RETURN_LOST_ANIMALS = EntityDataManager.func_187226_a(EntityRancher.class, DataSerializers.field_187198_h);
/*  30 */   private static final DataParameter<Boolean> FEED_COW = EntityDataManager.func_187226_a(EntityRancher.class, DataSerializers.field_187198_h);
/*  31 */   private static final DataParameter<Boolean> FEED_SHEEP = EntityDataManager.func_187226_a(EntityRancher.class, DataSerializers.field_187198_h);
/*  32 */   private static final DataParameter<Boolean> FEED_PIG = EntityDataManager.func_187226_a(EntityRancher.class, DataSerializers.field_187198_h);
/*  33 */   private static final DataParameter<Boolean> FEED_CHICKEN = EntityDataManager.func_187226_a(EntityRancher.class, DataSerializers.field_187198_h);
/*  34 */   private static final DataParameter<Boolean> HARVEST_COW = EntityDataManager.func_187226_a(EntityRancher.class, DataSerializers.field_187198_h);
/*  35 */   private static final DataParameter<Boolean> HARVEST_SHEEP = EntityDataManager.func_187226_a(EntityRancher.class, DataSerializers.field_187198_h);
/*     */   
/*     */   private VillageStructureType priorityPen;
/*     */   
/*     */   static {
/*  40 */     animHandler.addAnim("tektopia", "villager_take", "rancher_m", true);
/*  41 */     EntityVillagerTek.setupAnimations(animHandler, "rancher_m");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityRancher(World worldIn) {
/*  47 */     super(worldIn, ProfessionType.RANCHER, VillagerRole.VILLAGER.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/*  59 */     return animHandler;
/*     */   }
/*     */   
/*     */   protected void func_70088_a() {
/*  63 */     super.func_70088_a();
/*     */     
/*  65 */     registerAIFilter("return_lost_animals", RETURN_LOST_ANIMALS);
/*  66 */     registerAIFilter("feed_cow", FEED_COW);
/*  67 */     registerAIFilter("feed_sheep", FEED_SHEEP);
/*  68 */     registerAIFilter("feed_chicken", FEED_CHICKEN);
/*  69 */     registerAIFilter("feed_pig", FEED_PIG);
/*  70 */     registerAIFilter("harvest_cow", HARVEST_COW);
/*  71 */     registerAIFilter("harvest_sheep", HARVEST_SHEEP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/*  78 */     super.func_184651_r();
/*     */     
/*  80 */     getDesireSet().addItemDesire(new ItemDesire("CowFood", VillageStructureCowPen.isFood(), 1, 6, 16, v -> isAIFilterEnabled("feed_cow")));
/*  81 */     getDesireSet().addItemDesire(new ItemDesire("ChickenFood", VillageStructureChickenCoop.isFood(), 1, 6, 16, v -> isAIFilterEnabled("feed_chicken")));
/*  82 */     getDesireSet().addItemDesire(new ItemDesire("PigFood", VillageStructurePigPen.isFood(), 1, 6, 16, v -> isAIFilterEnabled("feed_pig")));
/*  83 */     getDesireSet().addItemDesire(new ItemDesire("SheepFood", VillageStructureSheepPen.isFood(), 1, 6, 16, v -> isAIFilterEnabled("feed_sheep")));
/*  84 */     getDesireSet().addItemDesire(new ItemDesire((Item)Items.field_151097_aZ, 1, 1, 1, v -> isAIFilterEnabled("harvest_sheep")));
/*  85 */     getDesireSet().addItemDesire(new ItemDesire(Items.field_151133_ar, 1, 2, 2, v -> isAIFilterEnabled("harvest_cow")));
/*     */     
/*  87 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIAttachLeadToLostAnimal(this, p -> p.isWorkTime()));
/*  88 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIReturnLostAnimal(this));
/*     */     
/*  90 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIFeedAnimal(this, VillageStructureType.COW_PEN, 0, "feed_cow"));
/*  91 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIFeedAnimal(this, VillageStructureType.CHICKEN_COOP, 1, "feed_chicken"));
/*  92 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIFeedAnimal(this, VillageStructureType.SHEEP_PEN, 2, "feed_sheep"));
/*  93 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIFeedAnimal(this, VillageStructureType.PIG_PEN, 3, "feed_pig"));
/*  94 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIHarvestAnimal(this, VillageStructureType.COW_PEN, new ItemStack(Items.field_151133_ar), p -> (p.isWorkTime() && p.isAIFilterEnabled("harvest_cow") && p.getVillage().getStorageCount(()) <= 3)));
/*  95 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIHarvestAnimal(this, VillageStructureType.SHEEP_PEN, new ItemStack((Item)Items.field_151097_aZ), p -> (p.isWorkTime() && p.isAIFilterEnabled("harvest_sheep"))));
/*     */   }
/*     */   
/*     */   public void func_70636_d() {
/*  99 */     super.func_70636_d();
/*     */   }
/*     */   
/*     */   public Predicate<ItemStack> isHarvestItem() {
/* 103 */     return p -> (p.func_77973_b() == Items.field_151117_aB || p.func_77973_b() == Items.field_151110_aK || p.func_77973_b() == Item.func_150898_a(Blocks.field_150325_L) || super.isHarvestItem().test(p));
/*     */   }
/*     */   
/*     */   public void setPriorityPen(VillageStructureType t) {
/* 107 */     this.priorityPen = t;
/*     */   }
/*     */   
/*     */   public VillageStructureType getPriorityPen() {
/* 111 */     return this.priorityPen;
/*     */   }
/*     */   
/*     */   protected boolean canVillagerPickupItem(ItemStack itemIn) {
/* 115 */     return (itemIn.func_77973_b() == Items.field_151110_aK || itemIn.func_77973_b() == Item.func_150898_a(Blocks.field_150325_L) || super.canVillagerPickupItem(itemIn));
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityRancher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */