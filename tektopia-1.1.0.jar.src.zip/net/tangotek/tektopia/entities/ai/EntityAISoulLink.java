/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.monster.EntityMob;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.pathfinding.Path;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.entities.EntityNecromancer;
/*     */ import net.tangotek.tektopia.entities.EntitySpiritSkull;
/*     */ 
/*     */ public class EntityAISoulLink
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityNecromancer necro;
/*     */   private EntitySpiritSkull skull;
/*     */   private EntityCreature target;
/*  22 */   private int abilityTime = 0;
/*  23 */   private final int ABILITY_LENGTH = 22;
/*     */   
/*     */   public EntityAISoulLink(EntityNecromancer v) {
/*  26 */     this.necro = v;
/*  27 */     func_75248_a(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  33 */     this.target = null;
/*  34 */     if (this.necro.isAITick() && this.necro.isReadyForSkull()) {
/*     */       
/*  36 */       List<EntityAnimal> animals = this.necro.field_70170_p.func_72872_a(EntityAnimal.class, this.necro.func_174813_aQ().func_186662_g(20.0D));
/*  37 */       this.target = animals.stream().filter(a -> (isCreatureInRange((EntityCreature)a) && !this.necro.isCreatureSkulled((EntityCreature)a))).findAny().orElse(null);
/*  38 */       if (this.target == null) {
/*     */         
/*  40 */         List<EntityMob> mobs = this.necro.field_70170_p.func_72872_a(EntityMob.class, this.necro.func_174813_aQ().func_186662_g(20.0D));
/*  41 */         Collections.shuffle(mobs);
/*  42 */         this.target = mobs.stream().filter(m -> { if (isCreatureInRange((EntityCreature)m) && m.func_70089_S()) if (EntityNecromancer.isMinion((EntityLivingBase)m) && !this.necro.isCreatureSkulled((EntityCreature)m));  return false; }).findAny().orElse(null);
/*     */       } 
/*     */       
/*  45 */       if (this.target != null) {
/*  46 */         Path path = this.necro.func_70661_as().func_179680_a(this.target.func_180425_c());
/*  47 */         if (path == null || path.func_75874_d() <= 1) {
/*  48 */           this.target = null;
/*     */         }
/*     */       } 
/*     */     } 
/*  52 */     return (this.target != null);
/*     */   }
/*     */   
/*     */   private boolean isCreatureInRange(EntityCreature c) {
/*  56 */     return (c.func_70068_e((Entity)this.necro) < 400.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  62 */     startAbility();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  68 */     return (this.abilityTime > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75252_g() {
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  80 */     if (this.abilityTime > 0) {
/*  81 */       this.abilityTime--;
/*  82 */       if (this.abilityTime == 12) {
/*  83 */         spawnSkull();
/*     */       }
/*     */     } 
/*     */     
/*  87 */     this.necro.func_70671_ap().func_75651_a((Entity)this.target, 30.0F, 30.0F);
/*     */ 
/*     */     
/*  90 */     super.func_75246_d();
/*     */   }
/*     */ 
/*     */   
/*     */   private void startAbility() {
/*  95 */     this.abilityTime = 22;
/*  96 */     this.necro.func_70661_as().func_75499_g();
/*  97 */     this.necro.playServerAnimation("necro_siphon");
/*  98 */     this.necro.func_184185_a(ModSoundEvents.deathSkullLeave, this.necro.field_70170_p.field_73012_v.nextFloat() * 0.4F + 1.2F, this.necro.field_70170_p.field_73012_v.nextFloat() * 0.4F + 0.8F);
/*  99 */     this.necro.setSpellTarget((Entity)this.target);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void stopAbility() {
/* 105 */     this.necro.stopServerAnimation("necro_siphon");
/* 106 */     this.necro.setSpellTarget(null);
/*     */   }
/*     */   
/*     */   private void spawnSkull() {
/* 110 */     this.skull = new EntitySpiritSkull(this.necro.field_70170_p);
/* 111 */     this.skull.func_70012_b(this.target.field_70165_t, this.target.field_70163_u + this.target.func_70047_e(), this.target.field_70161_v, this.target.field_70177_z, 0.0F);
/* 112 */     this.necro.field_70170_p.func_72838_d((Entity)this.skull);
/* 113 */     this.skull.setSkullCreature(this.target);
/* 114 */     this.necro.addSkull(this.skull);
/* 115 */     EntityNecromancer.makeMinion((EntityLivingBase)this.target, this.necro);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 120 */     stopAbility();
/* 121 */     this.abilityTime = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAISoulLink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */