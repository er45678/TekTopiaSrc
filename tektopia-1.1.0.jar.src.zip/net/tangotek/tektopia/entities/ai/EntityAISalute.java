/*    */ package net.tangotek.tektopia.entities.ai;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ import net.tangotek.tektopia.ModItems;
/*    */ import net.tangotek.tektopia.entities.EntityGuard;
/*    */ 
/*    */ public class EntityAISalute
/*    */   extends EntityAIBase {
/*    */   private EntityGuard guard;
/*    */   private EntityLivingBase saluteTarget;
/* 14 */   private long lastSalute = 0L;
/* 15 */   private int saluteTime = 0;
/*    */   
/*    */   public EntityAISalute(EntityGuard v) {
/* 18 */     this.guard = v;
/* 19 */     func_75248_a(1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 25 */     if (this.guard.isAITick("salute") && this.guard.field_70170_p.func_82737_E() - this.lastSalute > 2400L && !this.guard.isSleeping() && this.guard.func_70638_az() == null && 
/* 26 */       this.guard.hasVillage() && !this.guard.getVillage().enemySeenRecently()) {
/*    */       
/* 28 */       this.saluteTarget = (EntityLivingBase)this.guard.field_70170_p.func_72890_a((Entity)this.guard, 12.0D);
/* 29 */       if (this.saluteTarget != null) {
/* 30 */         return true;
/*    */       }
/*    */       
/* 33 */       if (!this.guard.isCaptain()) {
/*    */         
/* 35 */         List<EntityGuard> captains = this.guard.field_70170_p.func_175647_a(EntityGuard.class, this.guard.func_174813_aQ().func_186662_g(12.0D), g -> g.isCaptain());
/* 36 */         if (!captains.isEmpty()) {
/* 37 */           this.saluteTarget = (EntityLivingBase)captains.get(0);
/* 38 */           return true;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_75249_e() {
/* 50 */     startSalute();
/* 51 */     super.func_75249_e();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75253_b() {
/* 57 */     return (this.saluteTime > 0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_75246_d() {
/* 63 */     if (this.saluteTime > 0) {
/* 64 */       if (this.saluteTime == 10) {
/* 65 */         this.guard.stopServerAnimation("villager_salute");
/*    */         
/* 67 */         if (this.guard.func_70681_au().nextInt(3) == 0) {
/* 68 */           this.guard.modifyHappy(2);
/*    */         }
/*    */       } 
/* 71 */       this.guard.func_70625_a((Entity)this.saluteTarget, 30.0F, 30.0F);
/* 72 */       this.saluteTime--;
/*    */     } 
/*    */     
/* 75 */     super.func_75246_d();
/*    */   }
/*    */ 
/*    */   
/*    */   private void startSalute() {
/* 80 */     this.lastSalute = this.guard.field_70170_p.func_82737_E();
/* 81 */     this.saluteTime = 50;
/* 82 */     this.guard.func_70661_as().func_75499_g();
/* 83 */     this.guard.equipActionItem(ModItems.EMPTY_HAND_ITEM);
/* 84 */     this.guard.playServerAnimation("villager_salute");
/*    */   }
/*    */ 
/*    */   
/*    */   private void stopSalute() {
/* 89 */     this.guard.unequipActionItem(ModItems.EMPTY_HAND_ITEM);
/* 90 */     this.guard.stopServerAnimation("villager_salute");
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_75251_c() {
/* 95 */     stopSalute();
/* 96 */     this.saluteTime = 0;
/* 97 */     super.func_75251_c();
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAISalute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */