/*     */ package net.tangotek.tektopia.commands;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.Village;
/*     */ import net.tangotek.tektopia.VillageManager;
/*     */ import net.tangotek.tektopia.entities.EntityBard;
/*     */ import net.tangotek.tektopia.entities.EntityBlacksmith;
/*     */ import net.tangotek.tektopia.entities.EntityChild;
/*     */ import net.tangotek.tektopia.entities.EntityFarmer;
/*     */ import net.tangotek.tektopia.entities.EntityGuard;
/*     */ import net.tangotek.tektopia.entities.EntityMiner;
/*     */ import net.tangotek.tektopia.entities.EntityRancher;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ import net.tangotek.tektopia.structures.VillageStructureRancherPen;
/*     */ import net.tangotek.tektopia.structures.VillageStructureType;
/*     */ 
/*     */ class CommandPopulate extends CommandVillageBase {
/*     */   public CommandPopulate() {
/*  25 */     super("populate");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
/*  35 */     if (args.length > 1)
/*     */     {
/*  37 */       throw new WrongUsageException("commands.village.populate.usage", new Object[0]);
/*     */     }
/*     */     
/*  40 */     EntityPlayerMP entityPlayerMP = func_71521_c(sender);
/*  41 */     VillageManager vm = VillageManager.get(((EntityPlayer)entityPlayerMP).field_70170_p);
/*  42 */     Village village = vm.getVillageAt(entityPlayerMP.func_180425_c());
/*  43 */     if (village != null) {
/*  44 */       int skill = 1;
/*  45 */       if (args.length == 1) {
/*  46 */         skill = Math.min(Integer.valueOf(args[0]).intValue(), 100);
/*     */       }
/*     */       
/*  49 */       populateVillagers(village, skill);
/*  50 */       populateAnimals(village);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateAnimals(Village village) {
/*  57 */     populateAnimalPen(village, VillageStructureType.COW_PEN);
/*  58 */     populateAnimalPen(village, VillageStructureType.PIG_PEN);
/*  59 */     populateAnimalPen(village, VillageStructureType.CHICKEN_COOP);
/*  60 */     populateAnimalPen(village, VillageStructureType.SHEEP_PEN);
/*     */   }
/*     */   
/*     */   private void populateAnimalPen(Village v, VillageStructureType penType) {
/*  64 */     List<VillageStructure> pens = v.getStructures(penType);
/*  65 */     for (VillageStructure pen : pens) {
/*  66 */       if (pen instanceof VillageStructureRancherPen) {
/*  67 */         VillageStructureRancherPen rancherPen = (VillageStructureRancherPen)pen;
/*  68 */         List<EntityAnimal> animals = rancherPen.getEntitiesInside(rancherPen.getAnimalClass());
/*  69 */         animals.stream().forEach(a -> a.func_70106_y());
/*     */         
/*  71 */         for (int i = 0; i < 12; i++) {
/*  72 */           rancherPen.spawnAnimal(rancherPen.getDoorInside());
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void populateVillagers(Village village, int skill) {
/*  79 */     List<EntityVillagerTek> villagers = village.getWorld().func_72872_a(EntityVillagerTek.class, village.getAABB().func_72314_b(100.0D, 100.0D, 100.0D));
/*  80 */     for (EntityVillagerTek villager : villagers) {
/*  81 */       villager.func_70106_y();
/*     */     }
/*     */     
/*  84 */     List<VillageStructure> structs = village.getStructures(VillageStructureType.TOWNHALL);
/*  85 */     if (!structs.isEmpty()) {
/*  86 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityFarmer(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  87 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityFarmer(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  88 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityFarmer(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  89 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityFarmer(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  90 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityFarmer(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  91 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityFarmer(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*     */       
/*  93 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityRancher(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  94 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityRancher(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  95 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityRancher(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*     */       
/*  97 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityButcher(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  98 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityBlacksmith(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*  99 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityMiner(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 100 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityMiner(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 101 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityMiner(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 102 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityTeacher(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 103 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityChild(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 104 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityChild(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 105 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityChild(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*     */       
/* 107 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityGuard(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 108 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityGuard(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 109 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityGuard(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 110 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityGuard(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 111 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityGuard(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*     */       
/* 113 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityBard(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 114 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityChef(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 115 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityEnchanter(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 116 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityDruid(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/* 117 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityCleric(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*     */       
/* 119 */       spawnVillager(village, skill, (EntityVillagerTek)new EntityLumberjack(village.getWorld()), ((VillageStructure)structs.get(0)).getRandomFloorTile());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void spawnVillager(Village v, int skill, EntityVillagerTek villager, BlockPos spawnPos) {
/* 125 */     villager.func_70012_b(spawnPos.func_177958_n() + 0.5D, spawnPos.func_177956_o(), spawnPos.func_177952_p() + 0.5D, 0.0F, 0.0F);
/* 126 */     villager.func_180482_a(v.getWorld().func_175649_E(spawnPos), (IEntityLivingData)null);
/* 127 */     if ((villager.getProfessionType()).canCopy) {
/* 128 */       villager.setSkill(villager.getProfessionType(), skill + (int)(villager.func_70681_au().nextGaussian() * 30.0D));
/*     */     }
/* 130 */     villager.setIntelligence(skill);
/*     */     
/* 132 */     v.getWorld().func_72838_d((Entity)villager);
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\commands\CommandPopulate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */