/*    */ package net.tangotek.tektopia.generation;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.BlockBed;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.structure.StructureBoundingBox;
/*    */ import net.minecraft.world.gen.structure.StructureVillagePieces;
/*    */ import net.tangotek.tektopia.structures.VillageStructureType;
/*    */ 
/*    */ public class TekHouse2b
/*    */   extends StructureVillagePieces.House4Garden {
/*    */   private int villagersSpawned;
/*    */   
/*    */   public TekHouse2b(StructureVillagePieces.Start start, int type, Random rand, StructureBoundingBox bbox, EnumFacing facing) {
/* 20 */     super(start, type, rand, bbox, facing);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TekHouse2b() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_74875_a(World worldIn, Random randomIn, StructureBoundingBox structureBoundingBoxIn) {
/* 30 */     boolean result = super.func_74875_a(worldIn, randomIn, structureBoundingBoxIn);
/* 31 */     if (!this.field_189929_i) {
/* 32 */       placeBedPiece(worldIn, structureBoundingBoxIn, 1, 1, 2, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
/* 33 */       placeBedPiece(worldIn, structureBoundingBoxIn, 1, 1, 3, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
/*    */       
/* 35 */       placeBedPiece(worldIn, structureBoundingBoxIn, 3, 1, 2, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
/* 36 */       placeBedPiece(worldIn, structureBoundingBoxIn, 3, 1, 3, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
/*    */       
/* 38 */       func_189927_a(worldIn, structureBoundingBoxIn, randomIn, 2, 1, 0, EnumFacing.NORTH);
/*    */     } 
/* 40 */     return result;
/*    */   }
/*    */   
/*    */   public BlockPos getBlockPos(int x, int y, int z) {
/* 44 */     return new BlockPos(func_74865_a(x, z), func_74862_a(y), func_74873_b(x, z));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void func_189927_a(World w, StructureBoundingBox bb, Random rand, int x, int y, int z, EnumFacing facing) {
/* 49 */     super.func_189927_a(w, bb, rand, x, y, z, facing);
/* 50 */     TekStructureVillagePieces.addStructureFrame(w, bb, getBlockPos(x, y, z), VillageStructureType.HOME2);
/*    */   }
/*    */ 
/*    */   
/*    */   private void placeBedPiece(World worldIn, StructureBoundingBox bbox, int x, int y, int z, EnumFacing facing, BlockBed.EnumPartType partType) {
/* 55 */     IBlockState bedState = Blocks.field_150324_C.func_176223_P().func_177226_a((IProperty)BlockBed.field_176471_b, Boolean.valueOf(false)).func_177226_a((IProperty)BlockBed.field_185512_D, (Comparable)facing);
/* 56 */     func_175811_a(worldIn, bedState.func_177226_a((IProperty)BlockBed.field_176472_a, (Comparable)partType), x, y, z, bbox);
/* 57 */     func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), x, y + 1, z, bbox);
/*    */   }
/*    */   
/*    */   protected void func_74893_a(World worldIn, StructureBoundingBox structurebb, int x, int y, int z, int count) {}
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\generation\TekHouse2b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */