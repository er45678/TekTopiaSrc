/*    */ package net.tangotek.tektopia.entities;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.particle.Particle;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityAreaEffectCloud;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.MobEffects;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.EnumParticleTypes;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import net.tangotek.tektopia.client.ParticleSkull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityDeathCloud
/*    */   extends EntityAreaEffectCloud
/*    */ {
/*    */   private float angleRadians;
/*    */   
/*    */   public EntityDeathCloud(World worldIn) {
/* 28 */     super(worldIn);
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityDeathCloud(World worldIn, double x, double y, double z) {
/* 33 */     super(worldIn, x, y, z);
/* 34 */     func_184491_a(EnumParticleTypes.TOWN_AURA);
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_70071_h_() {
/* 39 */     super.func_70071_h_();
/*    */     
/* 41 */     if (this.field_70170_p.field_72995_K) {
/* 42 */       for (int i = 0; i < 4; i++) {
/* 43 */         this.angleRadians = (float)(this.angleRadians + 0.0035D);
/* 44 */         if (this.angleRadians > 1.0F) {
/* 45 */           this.angleRadians = 1.0F - this.angleRadians;
/*    */         }
/* 47 */         perimeterParticle(this.angleRadians, 0.0F);
/* 48 */         perimeterParticle(-this.angleRadians, -0.3F);
/* 49 */         interiorParticle();
/*    */       } 
/*    */     } else {
/*    */       
/* 53 */       double radiusSq = (func_184490_j() * func_184490_j());
/* 54 */       List<EntityPlayer> entList = this.field_70170_p.func_72872_a(EntityPlayer.class, func_174813_aQ());
/* 55 */       for (EntityPlayer insideEnt : entList) {
/* 56 */         if (insideEnt.func_70068_e((Entity)this) < radiusSq) {
/* 57 */           int duration = (insideEnt instanceof EntityPlayer) ? 160 : 80;
/* 58 */           insideEnt.func_70690_d(new PotionEffect(MobEffects.field_82731_v, duration));
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   private void perimeterParticle(float angleRadians, float radiusMod) {
/* 67 */     double motionY = Math.random() * 0.01D + 0.01D;
/*    */     
/* 69 */     float f1 = angleRadians * 6.2831855F;
/*    */     
/* 71 */     float xOffset = MathHelper.func_76134_b(f1) * (func_184490_j() + radiusMod);
/* 72 */     float zOffset = MathHelper.func_76126_a(f1) * (func_184490_j() + radiusMod);
/*    */     
/* 74 */     Vec3d pos = new Vec3d(this.field_70165_t + xOffset, this.field_70163_u, this.field_70161_v + zOffset);
/*    */     
/* 76 */     this.field_70170_p.func_175688_a(EnumParticleTypes.DRAGON_BREATH, pos.field_72450_a, pos.field_72448_b, pos.field_72449_c, 0.0D, motionY, 0.0D, new int[0]);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   private void interiorParticle() {
/* 81 */     double motionY = Math.random() * 0.01D + 0.01D;
/* 82 */     float f1 = this.field_70170_p.field_73012_v.nextFloat() * 6.2831855F;
/* 83 */     float xOffset = MathHelper.func_76134_b(f1) * func_184490_j() * this.field_70170_p.field_73012_v.nextFloat();
/* 84 */     float zOffset = MathHelper.func_76126_a(f1) * func_184490_j() * this.field_70170_p.field_73012_v.nextFloat();
/*    */     
/* 86 */     Vec3d pos = new Vec3d(this.field_70165_t + xOffset, this.field_70163_u, this.field_70161_v + zOffset);
/* 87 */     ParticleSkull part = new ParticleSkull(this.field_70170_p, Minecraft.func_71410_x().func_110434_K(), pos, motionY);
/* 88 */     part.radius = this.field_70146_Z.nextGaussian() * 0.05D;
/* 89 */     part.radiusGrow = 0.002D;
/* 90 */     part.torque = Math.random() * 0.04D - 0.02D;
/* 91 */     part.lifeTime = this.field_70146_Z.nextInt(20) + 10;
/* 92 */     part.func_189213_a();
/* 93 */     (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)part);
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityDeathCloud.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */