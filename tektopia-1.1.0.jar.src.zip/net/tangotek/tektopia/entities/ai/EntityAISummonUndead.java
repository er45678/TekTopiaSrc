/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.monster.EntityMob;
/*     */ import net.minecraft.entity.monster.EntityWitherSkeleton;
/*     */ import net.minecraft.entity.monster.EntityZombie;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.entities.EntityNecromancer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAISummonUndead
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityNecromancer necro;
/*  23 */   private int summonTime = 0;
/*  24 */   private int cooldownTick = 0;
/*     */   protected final int checkInterval;
/*     */   private BlockPos summonPos;
/*  27 */   private final int MAX_SUMMONS = 50;
/*  28 */   private int summonCount = 0;
/*     */   
/*     */   public EntityAISummonUndead(EntityNecromancer necro, int checkInterval) {
/*  31 */     this.checkInterval = checkInterval;
/*  32 */     this.necro = necro;
/*  33 */     func_75248_a(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  38 */     if (this.necro.isAITick() && isSummonReady(this.necro) && 
/*  39 */       this.necro.getMinions().size() < this.necro.getMaxSummons()) {
/*  40 */       List<EntityZombie> zombs = this.necro.field_70170_p.func_72872_a(EntityZombie.class, this.necro.func_174813_aQ().func_72314_b(30.0D, 10.0D, 30.0D));
/*  41 */       if (zombs.size() < this.necro.getLevel() * 2) {
/*  42 */         this.summonPos = findSummonPos(this.necro.func_70661_as().func_75500_f() ? 2.0F : 10.0F);
/*  43 */         return (this.summonPos != null);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  48 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isSummonReady(EntityNecromancer necro) {
/*  52 */     if (this.summonCount >= 50) {
/*  53 */       return false;
/*     */     }
/*  55 */     if (this.necro.getMinions().size() < 1) {
/*  56 */       return true;
/*     */     }
/*     */     
/*  59 */     if (this.necro.field_70173_aa > this.cooldownTick && (
/*  60 */       this.necro.getMinions().size() < 1 || this.necro.func_70681_au().nextInt(this.checkInterval) == 0)) {
/*  61 */       return true;
/*     */     }
/*     */     
/*  64 */     return false;
/*     */   }
/*     */   
/*     */   public void func_75249_e() {
/*  68 */     this.necro.func_70661_as().func_75499_g();
/*  69 */     startSummoning();
/*  70 */     super.func_75249_e();
/*     */   }
/*     */   
/*     */   public boolean func_75253_b() {
/*  74 */     return (this.summonTime > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  79 */     if (this.summonTime > 0) {
/*  80 */       this.necro.faceLocation(this.summonPos.func_177958_n(), this.summonPos.func_177952_p(), 100.0F);
/*  81 */       this.summonTime--;
/*  82 */       if (this.summonTime == 12) {
/*  83 */         spawnMinion();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75252_g() {
/*  91 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private BlockPos findSummonPos(float forwardDist) {
/*  96 */     float distance = forwardDist;
/*  97 */     float f1 = MathHelper.func_76126_a(this.necro.field_70177_z * 0.017453292F);
/*  98 */     float f2 = MathHelper.func_76134_b(this.necro.field_70177_z * 0.017453292F);
/*  99 */     double behindX = (-distance * f1);
/* 100 */     double behindZ = (distance * f2);
/*     */     
/* 102 */     BlockPos testPos = new BlockPos(this.necro.field_70165_t + behindX, this.necro.field_70163_u, this.necro.field_70161_v + behindZ);
/* 103 */     EntityZombie zombie = new EntityZombie(this.necro.field_70170_p);
/* 104 */     int searchBoxXZ = 8;
/* 105 */     for (int l = 0; l < 50; l++) {
/* 106 */       int i1 = testPos.func_177958_n() + MathHelper.func_76136_a(this.necro.field_70170_p.field_73012_v, -searchBoxXZ, searchBoxXZ);
/* 107 */       int j1 = testPos.func_177956_o() + MathHelper.func_76136_a(this.necro.field_70170_p.field_73012_v, -5, 5);
/* 108 */       int k1 = testPos.func_177952_p() + MathHelper.func_76136_a(this.necro.field_70170_p.field_73012_v, -searchBoxXZ, searchBoxXZ);
/*     */       
/* 110 */       BlockPos bp = new BlockPos(i1, j1, k1);
/* 111 */       if (this.necro.field_70170_p.isSideSolid(bp.func_177977_b(), EnumFacing.UP)) {
/* 112 */         zombie.func_70107_b(i1 + 0.5D, j1, k1 + 0.5D);
/* 113 */         if (zombie.func_70058_J() && (
/* 114 */           !this.necro.hasVillage() || !this.necro.getVillage().isInStructure(bp))) {
/* 115 */           return bp;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 121 */     return null;
/*     */   }
/*     */   
/*     */   private void startSummoning() {
/* 125 */     this.necro.debugOut("Summoning undead minion [ " + this.summonPos + "] Starting");
/* 126 */     this.summonTime = 47;
/* 127 */     this.necro.playServerAnimation("necro_summon");
/* 128 */     this.necro.func_184185_a(ModSoundEvents.deathSummon, this.necro.func_70681_au().nextFloat() * 0.2F + 1.2F, this.necro.func_70681_au().nextFloat() * 0.2F + 0.9F);
/*     */   }
/*     */   
/*     */   private void stopSummoning() {
/* 132 */     this.necro.debugOut("Summoning complete [ " + this.summonPos + "] Starting");
/* 133 */     this.necro.stopServerAnimation("necro_summon");
/*     */   }
/*     */ 
/*     */   
/*     */   private void spawnMinion() {
/*     */     EntityZombie entityZombie;
/* 139 */     if (this.necro.getLevel() == 5 && this.necro.func_70681_au().nextBoolean()) {
/* 140 */       EntityWitherSkeleton entityWitherSkeleton = this.necro.createWitherSkeleton(this.summonPos);
/* 141 */     } else if (this.necro.getLevel() == 4 && this.necro.func_70681_au().nextInt(4) == 0) {
/* 142 */       EntityWitherSkeleton entityWitherSkeleton = this.necro.createWitherSkeleton(this.summonPos);
/*     */     } else {
/* 144 */       entityZombie = this.necro.createZombie(this.summonPos);
/*     */     } 
/* 146 */     this.necro.field_70170_p.func_72838_d((Entity)entityZombie);
/* 147 */     this.necro.addMinion((EntityMob)entityZombie);
/* 148 */     entityZombie.func_184185_a(ModSoundEvents.deathSummonTarget, this.necro.func_70681_au().nextFloat() * 0.4F + 0.8F, this.necro.func_70681_au().nextFloat() * 0.4F + 0.8F);
/*     */     
/* 150 */     this.summonCount++;
/* 151 */     this.necro.playSound(ModSoundEvents.deathSummonEnd);
/* 152 */     this.cooldownTick = this.necro.field_70173_aa + this.necro.getLevelCooldown(MathHelper.func_76136_a(this.necro.func_70681_au(), 30, 50) + this.necro.getMinions().size() * 20);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 157 */     this.summonTime = 0;
/* 158 */     stopSummoning();
/* 159 */     super.func_75251_c();
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAISummonUndead.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */