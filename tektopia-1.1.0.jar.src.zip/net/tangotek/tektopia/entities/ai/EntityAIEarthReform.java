/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.entities.EntityDruid;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.structures.VillageStructureMineshaft;
/*     */ import net.tangotek.tektopia.tickjob.TickJob;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAIEarthReform
/*     */   extends EntityAIMoveToBlock
/*     */ {
/*     */   private boolean arrived = false;
/*  18 */   private EntityDruid druid = null;
/*  19 */   private int castTime = 0;
/*  20 */   private final int CAST_TIME = 80;
/*     */   
/*     */   private final EntityVillagerTek villager;
/*     */   private VillageStructureMineshaft mineshaft;
/*     */   
/*     */   public EntityAIEarthReform(EntityVillagerTek entityIn) {
/*  26 */     super((EntityVillageNavigator)entityIn);
/*  27 */     this.villager = entityIn;
/*  28 */     this.druid = (EntityDruid)entityIn;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  34 */     if (this.villager.isAITick("cast_earth_reform") && this.villager.hasVillage() && this.villager.isWorkTime() && this.druid.isEarthReformTime()) {
/*  35 */       this.mineshaft = this.villager.getVillage().requestMineshaft(this.villager, m -> (m.getTunnelLength() > 3 && m.getPlayersInside().isEmpty() && m.getDruid() == null), (C, B) -> (C.getTunnelLength() > B.getTunnelLength() && C.getTunnelLength() > 10));
/*  36 */       if (this.mineshaft != null) {
/*  37 */         return super.func_75250_a();
/*     */       }
/*     */     } 
/*     */     
/*  41 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockPos getDestinationBlock() {
/*  46 */     BlockPos destBlock = this.mineshaft.getDoorOutside(2);
/*  47 */     if (!isWalkable(destBlock, (EntityVillageNavigator)this.villager)) {
/*  48 */       destBlock = this.mineshaft.getDoorOutside(1);
/*     */     }
/*  50 */     return destBlock;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isNearWalkPos() {
/*  55 */     if (getWalkPos() != null) {
/*  56 */       return (getWalkPos().func_177957_d(this.villager.getX(), this.villager.getY(), this.villager.getZ()) < 0.5D);
/*     */     }
/*     */     
/*  59 */     return super.isNearWalkPos();
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockPos findWalkPos() {
/*  64 */     return this.destinationPos;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onArrival() {
/*  69 */     if (!this.arrived) {
/*  70 */       tryCast();
/*     */     }
/*  72 */     this.arrived = true;
/*  73 */     super.onArrival();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  79 */     this.mineshaft.setDruid(this.druid);
/*  80 */     super.func_75249_e();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75252_g() {
/*  86 */     return (this.castTime <= 0);
/*     */   }
/*     */   
/*     */   protected void tryCast() {
/*  90 */     if (this.villager.func_70089_S()) {
/*  91 */       this.mineshaft.updateOccupants();
/*  92 */       if (this.mineshaft.getTunnelMiner() == null) {
/*  93 */         this.castTime = 80;
/*     */         
/*  95 */         this.villager.playServerAnimation("villager_cast_forward");
/*  96 */         this.druid.setCastingEarthReform(this.mineshaft.getMiningPos());
/*  97 */         this.villager.modifyHunger(-8);
/*  98 */         this.villager.func_70661_as().func_75499_g();
/*  99 */         this.villager.addJob(new TickJob(4, 0, false, () -> this.villager.playSound(ModSoundEvents.earthRumble)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/* 106 */     this.castTime--;
/*     */     
/* 108 */     if (this.castTime > 0) {
/* 109 */       this.villager.faceLocation(this.mineshaft.getMiningPos().func_177958_n(), this.mineshaft.getMiningPos().func_177952_p(), 30.0F);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (this.castTime == 38) {
/* 121 */       this.mineshaft.updateOccupants();
/* 122 */       if (this.mineshaft.getTunnelMiner() == null) {
/* 123 */         this.villager.tryAddSkill(ProfessionType.DRUID, 9);
/*     */ 
/*     */         
/* 126 */         this.mineshaft.regrow(this.villager);
/*     */ 
/*     */         
/* 129 */         for (int i = 0; i < 3; i++) {
/* 130 */           if (this.villager.func_70681_au().nextInt(100) < this.villager.getSkill(ProfessionType.DRUID)) {
/* 131 */             this.mineshaft.regrow(this.villager);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     super.func_75246_d();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 143 */     this.villager.stopServerAnimation("villager_cast_forward");
/* 144 */     this.arrived = false;
/* 145 */     this.castTime = 0;
/* 146 */     this.druid.setCastingEarthReform(null);
/* 147 */     this.mineshaft.setDruid(null);
/*     */     
/* 149 */     super.func_75251_c();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/* 154 */     if (this.mineshaft.getTunnelMiner() != null) {
/* 155 */       return false;
/*     */     }
/* 157 */     if (this.castTime > 0) {
/* 158 */       return true;
/*     */     }
/* 160 */     return super.func_75253_b();
/*     */   }
/*     */ 
/*     */   
/*     */   void updateMovementMode() {
/* 165 */     this.villager.setMovementMode(this.villager.getDefaultMovement());
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIEarthReform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */