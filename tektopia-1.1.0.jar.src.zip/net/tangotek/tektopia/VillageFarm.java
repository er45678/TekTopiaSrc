/*     */ package net.tangotek.tektopia;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockCrops;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.event.world.BlockEvent;
/*     */ 
/*     */ public class VillageFarm
/*     */ {
/*  21 */   private static int nextId = 1;
/*     */   private final int farmId;
/*  23 */   private int cropUpdateTick = 0;
/*     */   protected final World world;
/*  25 */   private int distanceToVillageCenter = 0;
/*     */   protected AxisAlignedBB aabb;
/*  27 */   protected List<BlockPos> fullCrops = new ArrayList<>();
/*  28 */   protected Set<BlockPos> activeFarmland = new HashSet<>();
/*  29 */   private int blocks = 0;
/*     */   private double weightScore;
/*  31 */   public static int MAX_AREA = 1000;
/*     */   
/*     */   public VillageFarm(World w, BlockPos startPos, Village v) {
/*  34 */     this.farmId = nextId;
/*  35 */     nextId++;
/*  36 */     this.world = w;
/*  37 */     this.aabb = new AxisAlignedBB(startPos, startPos);
/*  38 */     Set<BlockPos> tested = new HashSet<>();
/*  39 */     testFarmLand(startPos, tested);
/*  40 */     this.blocks = tested.size();
/*  41 */     this.distanceToVillageCenter = (int)getFarmCenter().func_72438_d(new Vec3d(v.getCenter().func_177958_n(), v.getCenter().func_177956_o(), v.getCenter().func_177952_p()));
/*  42 */     this.cropUpdateTick = 500 + this.world.field_73012_v.nextInt(500);
/*     */     
/*  44 */     updateWeightScore(v.getSize());
/*     */   }
/*     */   
/*     */   public int size() {
/*  48 */     return this.blocks;
/*     */   }
/*     */   
/*     */   public void updateWeightScore(int villageSize) {
/*  52 */     this.weightScore = villageSize / this.distanceToVillageCenter * this.blocks;
/*     */   }
/*     */   
/*     */   public double getWeightScore() {
/*  56 */     return this.weightScore;
/*     */   }
/*     */   
/*     */   private Vec3d getFarmCenter() {
/*  60 */     return new Vec3d(this.aabb.field_72340_a + (this.aabb.field_72336_d - this.aabb.field_72340_a) * 0.5D, this.aabb.field_72338_b + (this.aabb.field_72337_e - this.aabb.field_72338_b) * 0.5D, this.aabb.field_72339_c + (this.aabb.field_72334_f - this.aabb.field_72339_c) * 0.5D);
/*     */   }
/*     */   
/*     */   public boolean isBlockInside(BlockPos pos) {
/*  64 */     if (pos.func_177958_n() >= this.aabb.field_72340_a && pos.func_177958_n() <= this.aabb.field_72336_d && 
/*  65 */       pos.func_177952_p() >= this.aabb.field_72339_c && pos.func_177952_p() <= this.aabb.field_72334_f) {
/*  66 */       return (pos.func_177956_o() >= this.aabb.field_72338_b && pos.func_177956_o() <= this.aabb.field_72337_e);
/*     */     }
/*     */ 
/*     */     
/*  70 */     return false;
/*     */   }
/*     */   
/*     */   public BlockPos getMaxAgeCrop() {
/*  74 */     while (!this.fullCrops.isEmpty()) {
/*  75 */       BlockPos pos = this.fullCrops.remove(this.world.field_73012_v.nextInt(this.fullCrops.size()));
/*  76 */       if (isMaxAgeCrop(this.world, pos)) {
/*  77 */         return pos;
/*     */       }
/*     */     } 
/*  80 */     return null;
/*     */   }
/*     */   
/*     */   public BlockPos getFarmland(Predicate<BlockPos> pred) {
/*  84 */     for (int i = 0; i < 20; i++) {
/*  85 */       int x = MathHelper.func_76136_a(this.world.field_73012_v, (int)this.aabb.field_72340_a, (int)this.aabb.field_72336_d);
/*  86 */       int z = MathHelper.func_76136_a(this.world.field_73012_v, (int)this.aabb.field_72339_c, (int)this.aabb.field_72334_f);
/*  87 */       BlockPos pos = new BlockPos(x, this.aabb.field_72338_b, z);
/*  88 */       if (isNearWater(pos) && isFarmlandAdjacent(pos) && 
/*  89 */         pred.test(pos) && 
/*  90 */         !this.activeFarmland.contains(pos)) {
/*  91 */         this.activeFarmland.add(pos);
/*  92 */         return pos;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  98 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isFarmlandAdjacent(BlockPos pos) {
/* 102 */     int count = 0;
/* 103 */     if (this.world.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150458_ak) {
/* 104 */       count++;
/*     */     }
/* 106 */     if (this.world.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150458_ak) {
/* 107 */       count++;
/*     */     }
/* 109 */     if (this.world.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150458_ak) {
/* 110 */       count++;
/*     */     }
/* 112 */     if (this.world.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150458_ak) {
/* 113 */       count++;
/*     */     }
/* 115 */     return (count >= 2);
/*     */   }
/*     */   
/*     */   private boolean isNearWater(BlockPos cropPos) {
/* 119 */     for (BlockPos testPos : BlockPos.func_177980_a(cropPos.func_177982_a(-4, 0, -4), cropPos.func_177982_a(4, 0, 4))) {
/* 120 */       Block testBlock = this.world.func_180495_p(testPos).func_177230_c();
/* 121 */       if (testBlock == Blocks.field_150355_j || testBlock == Blocks.field_150358_i) {
/* 122 */         return true;
/*     */       }
/*     */     } 
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   public int distanceToVillageCenter() {
/* 129 */     return this.distanceToVillageCenter;
/*     */   }
/*     */   
/*     */   public void update(BlockPos villageCenter) {
/* 133 */     this.cropUpdateTick--;
/* 134 */     if (this.cropUpdateTick <= 0) {
/* 135 */       refreshFullCrops();
/* 136 */       this.activeFarmland.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void testFarmLand(BlockPos pos, Set<BlockPos> tested) {
/* 141 */     if (isFarmLand(this.world, pos) && getArea() < MAX_AREA && !tested.contains(pos)) {
/* 142 */       this.aabb = this.aabb.func_111270_a(new AxisAlignedBB(pos, pos));
/* 143 */       tested.add(pos);
/*     */       
/* 145 */       if (isMaxAgeCrop(this.world, pos.func_177984_a())) {
/* 146 */         this.fullCrops.add(pos.func_177984_a());
/*     */       }
/* 148 */       testFarmLand(pos.func_177976_e(), tested);
/* 149 */       testFarmLand(pos.func_177974_f(), tested);
/* 150 */       testFarmLand(pos.func_177978_c(), tested);
/* 151 */       testFarmLand(pos.func_177968_d(), tested);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onCropGrowEvent(BlockEvent.CropGrowEvent event) {
/* 156 */     if (isBlockInside(event.getPos().func_177977_b()) && 
/* 157 */       isMaxAgeCrop(this.world, event.getPos()))
/*     */     {
/* 159 */       this.fullCrops.add(event.getPos());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void refreshFullCrops() {
/* 165 */     this.fullCrops.clear();
/* 166 */     for (int x = (int)this.aabb.field_72340_a; x <= (int)this.aabb.field_72336_d; x++) {
/* 167 */       for (int z = (int)this.aabb.field_72339_c; z <= (int)this.aabb.field_72334_f; z++) {
/* 168 */         BlockPos pos = (new BlockPos(x, this.aabb.field_72338_b, z)).func_177984_a();
/* 169 */         if (isMaxAgeCrop(this.world, pos)) {
/* 170 */           this.fullCrops.add(pos);
/*     */         }
/*     */       } 
/*     */     } 
/* 174 */     this.cropUpdateTick = 250 + this.world.field_73012_v.nextInt(250);
/*     */   }
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getAABB() {
/* 179 */     return this.aabb;
/*     */   }
/*     */   
/*     */   public Vec3d getCenter() {
/* 183 */     return this.aabb.func_189972_c();
/*     */   }
/*     */   
/*     */   public String debug() {
/* 187 */     String result = "Farm #" + this.farmId + "  fullCrops: " + this.fullCrops.size() + " W: " + (int)getWeightScore() + "  C: " + new BlockPos(getCenter()) + " XZ: " + (this.aabb.field_72336_d - this.aabb.field_72340_a) + ", " + (this.aabb.field_72334_f - this.aabb.field_72339_c);
/* 188 */     return result;
/*     */   }
/*     */   
/*     */   public int getArea() {
/* 192 */     return (int)(this.aabb.field_72336_d - this.aabb.field_72340_a) * (int)(this.aabb.field_72334_f - this.aabb.field_72339_c);
/*     */   }
/*     */   
/*     */   public static boolean isFarmLand(World world, BlockPos pos) {
/* 196 */     Block block = world.func_180495_p(pos).func_177230_c();
/* 197 */     return (block == Blocks.field_150458_ak);
/*     */   }
/*     */   
/*     */   public static boolean isMaxAgeCrop(World world, BlockPos pos) {
/* 201 */     IBlockState iblockstate = world.func_180495_p(pos);
/* 202 */     Block block = iblockstate.func_177230_c();
/* 203 */     return (block instanceof BlockCrops && ((BlockCrops)block).func_185525_y(iblockstate));
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\VillageFarm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */