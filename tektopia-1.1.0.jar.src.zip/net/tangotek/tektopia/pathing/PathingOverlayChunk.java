/*    */ package net.tangotek.tektopia.pathing;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.ChunkPos;
/*    */ 
/*    */ 
/*    */ public class PathingOverlayChunk
/*    */ {
/*    */   private final ChunkPos chunkPos;
/* 14 */   private Map<BlockPos, PathingNodeClient> nodes = new HashMap<>();
/*    */   
/* 16 */   private final int RENDER_RADIUS = 30;
/* 17 */   private final int RENDER_RADIUS_SQ = 900;
/*    */   
/*    */   public PathingOverlayChunk(ChunkPos cp) {
/* 20 */     this.chunkPos = cp;
/*    */   }
/*    */   
/*    */   public void putNode(PathingNodeClient node) {
/* 24 */     if (node.isDestroyed) {
/* 25 */       this.nodes.remove(node.pos);
/*    */     }
/* 27 */     else if (this.nodes.put(node.pos, node) != null) {
/* 28 */       node.setAge(400);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void renderOverlays(WorldClient world, BufferBuilder vertexBuffer, double viewX, double viewY, double viewZ) {
/* 33 */     if (this.chunkPos.func_180334_c() - viewX > 30.0D || viewX - this.chunkPos.func_180332_e() > 30.0D || this.chunkPos.func_180333_d() - viewZ > 30.0D || viewZ - this.chunkPos.func_180330_f() > 30.0D) {
/*    */       return;
/*    */     }
/* 36 */     for (PathingNodeClient node : this.nodes.values()) {
/* 37 */       if (node.pos.func_177954_c(viewX, viewY, viewZ) < 900.0D) {
/* 38 */         renderNode(world, vertexBuffer, node);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void renderNode(WorldClient world, BufferBuilder vertexBuffer, PathingNodeClient node) {
/* 46 */     for (int index = 0; index < 4; index++) {
/* 47 */       vertexBuffer.func_181662_b(node.getX(index), node.getY(index), node.getZ(index))
/* 48 */         .func_181669_b(170, 170, 170, 140).func_181675_d();
/*    */     }
/*    */ 
/*    */     
/* 52 */     node.connections.forEach(conn -> {
/*    */           double innerEdge = 0.25D;
/*    */           double outerEdge = 0.75D;
/*    */           double width = 0.15D;
/*    */           double gap = 0.03D;
/*    */           double x = node.pos.func_177958_n() + 0.5D;
/*    */           double z = node.pos.func_177952_p() + 0.5D;
/*    */           double y = node.pos.func_177956_o() + 0.05D;
/*    */           for (int index = 0; index < 4; index++) {
/*    */             if (conn.xOffset == 0) {
/*    */               if (conn.zOffset == 1) {
/*    */                 vertexBuffer.func_181662_b(x - 0.03D, y, z + 0.25D).func_181669_b(98, 209, 83, 160).func_181675_d();
/*    */                 vertexBuffer.func_181662_b(x - 0.03D - 0.15D, y, z + 0.25D).func_181669_b(98, 209, 83, 160).func_181675_d();
/*    */                 vertexBuffer.func_181662_b(x - 0.03D - 0.15D, y + conn.yOffset, z + 0.75D).func_181669_b(230, 230, 110, 160).func_181675_d();
/*    */                 vertexBuffer.func_181662_b(x - 0.03D, y + conn.yOffset, z + 0.75D).func_181669_b(230, 230, 110, 160).func_181675_d();
/*    */               } else {
/*    */                 vertexBuffer.func_181662_b(x + 0.03D, y, z - 0.25D).func_181669_b(98, 209, 83, 160).func_181675_d();
/*    */                 vertexBuffer.func_181662_b(x + 0.03D + 0.15D, y, z - 0.25D).func_181669_b(98, 209, 83, 160).func_181675_d();
/*    */                 vertexBuffer.func_181662_b(x + 0.03D + 0.15D, y + conn.yOffset, z - 0.75D).func_181669_b(230, 230, 110, 160).func_181675_d();
/*    */                 vertexBuffer.func_181662_b(x + 0.03D, y + conn.yOffset, z - 0.75D).func_181669_b(230, 230, 110, 160).func_181675_d();
/*    */               } 
/*    */             } else if (conn.xOffset == 1) {
/*    */               vertexBuffer.func_181662_b(x + 0.25D, y, z + 0.03D).func_181669_b(98, 209, 83, 160).func_181675_d();
/*    */               vertexBuffer.func_181662_b(x + 0.25D, y, z + 0.03D + 0.15D).func_181669_b(98, 209, 83, 160).func_181675_d();
/*    */               vertexBuffer.func_181662_b(x + 0.75D, y + conn.yOffset, z + 0.03D + 0.15D).func_181669_b(230, 230, 110, 160).func_181675_d();
/*    */               vertexBuffer.func_181662_b(x + 0.75D, y + conn.yOffset, z + 0.03D).func_181669_b(230, 230, 110, 160).func_181675_d();
/*    */             } else {
/*    */               vertexBuffer.func_181662_b(x - 0.25D, y, z - 0.03D).func_181669_b(98, 209, 83, 160).func_181675_d();
/*    */               vertexBuffer.func_181662_b(x - 0.25D, y, z - 0.03D - 0.15D).func_181669_b(98, 209, 83, 160).func_181675_d();
/*    */               vertexBuffer.func_181662_b(x - 0.75D, y + conn.yOffset, z - 0.03D - 0.15D).func_181669_b(230, 230, 110, 160).func_181675_d();
/*    */               vertexBuffer.func_181662_b(x - 0.75D, y + conn.yOffset, z - 0.03D).func_181669_b(230, 230, 110, 160).func_181675_d();
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\pathing\PathingOverlayChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */