/*     */ package net.tangotek.tektopia.entities;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.EnumDyeColor;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.ItemTagType;
/*     */ import net.tangotek.tektopia.ModItems;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.TekVillager;
/*     */ import net.tangotek.tektopia.VillagerRole;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAICraftItems;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAISmelting;
/*     */ import net.tangotek.tektopia.entities.crafting.Recipe;
/*     */ import net.tangotek.tektopia.storage.ItemDesire;
/*     */ import net.tangotek.tektopia.structures.VillageStructureType;
/*     */ 
/*     */ public class EntityChef extends EntityVillagerTek {
/*  30 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityChef.class);
/*     */   
/*  32 */   private static final DataParameter<Boolean> COOK_BEEF = EntityDataManager.func_187226_a(EntityChef.class, DataSerializers.field_187198_h);
/*  33 */   private static final DataParameter<Boolean> COOK_MUTTON = EntityDataManager.func_187226_a(EntityChef.class, DataSerializers.field_187198_h);
/*  34 */   private static final DataParameter<Boolean> COOK_CHICKEN = EntityDataManager.func_187226_a(EntityChef.class, DataSerializers.field_187198_h);
/*  35 */   private static final DataParameter<Boolean> COOK_PORK = EntityDataManager.func_187226_a(EntityChef.class, DataSerializers.field_187198_h);
/*  36 */   private static final DataParameter<Boolean> COOK_POTATO = EntityDataManager.func_187226_a(EntityChef.class, DataSerializers.field_187198_h);
/*  37 */   private static final DataParameter<Boolean> SMELT_CHARCOAL = EntityDataManager.func_187226_a(EntityChef.class, DataSerializers.field_187198_h);
/*     */   
/*  39 */   private static List<Recipe> craftSet = buildCraftSet();
/*     */   
/*  41 */   private static final Map<String, DataParameter<Boolean>> RECIPE_PARAMS = new HashMap<>();
/*     */   static {
/*  43 */     craftSet.forEach(r -> (DataParameter)RECIPE_PARAMS.put(r.getAiFilter(), EntityDataManager.func_187226_a(EntityChef.class, DataSerializers.field_187198_h)));
/*     */ 
/*     */ 
/*     */     
/*  47 */     animHandler.addAnim("tektopia", "villager_take", "chef_m", false);
/*  48 */     animHandler.addAnim("tektopia", "villager_cook", "chef_m", false);
/*  49 */     EntityVillagerTek.setupAnimations(animHandler, "chef_m");
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityChef(World worldIn) {
/*  54 */     super(worldIn, ProfessionType.CHEF, VillagerRole.VILLAGER.value);
/*     */   }
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/*  58 */     return animHandler;
/*     */   }
/*     */   
/*     */   protected void func_70088_a() {
/*  62 */     super.func_70088_a();
/*     */     
/*  64 */     registerAIFilter("cook_beef", COOK_BEEF);
/*  65 */     registerAIFilter("cook_pork", COOK_PORK);
/*  66 */     registerAIFilter("cook_mutton", COOK_MUTTON);
/*  67 */     registerAIFilter("cook_chicken", COOK_CHICKEN);
/*  68 */     registerAIFilter("cook_potato", COOK_POTATO);
/*  69 */     registerAIFilter("smelt_charcoal", SMELT_CHARCOAL);
/*  70 */     craftSet.forEach(r -> registerAIFilter(r.getAiFilter(), RECIPE_PARAMS.get(r.getAiFilter())));
/*     */   }
/*     */   
/*     */   protected void func_184651_r() {
/*  74 */     super.func_184651_r();
/*     */     
/*  76 */     getDesireSet().addItemDesire(new ItemDesire("Fuel", EntityAISmelting.getBestFuel(), 1, 6, 10, null));
/*  77 */     getDesireSet().addItemDesire(new ItemDesire(Blocks.field_150364_r, 0, 4, 8, p -> p.isAIFilterEnabled("smelt_charcoal")));
/*  78 */     getDesireSet().addItemDesire(new ItemDesire("Cookable", bestCookable(this), 0, getSkillLerp(ProfessionType.CHEF, 1, 3) * 8, 0, null));
/*  79 */     craftSet.forEach(r -> getDesireSet().addRecipeDesire(r));
/*     */ 
/*     */     
/*  82 */     addTask(50, (EntityAIBase)new EntityAIEmptyFurnace(this, VillageStructureType.KITCHEN, takeFromFurnace()));
/*  83 */     addTask(50, (EntityAIBase)new EntityAISmelting(this, VillageStructureType.KITCHEN, p -> (!hasCoal(p, 1) && p.isAIFilterEnabled("smelt_charcoal")), p -> Integer.valueOf((p.func_77973_b() == Item.func_150898_a(Blocks.field_150364_r)) ? 1 : 0), () -> tryAddSkill(ProfessionType.CHEF, 10)));
/*  84 */     addTask(50, (EntityAIBase)new EntityAISmelting(this, VillageStructureType.KITCHEN, p -> true, bestCookable(this), () -> tryAddSkill(ProfessionType.CHEF, 3)));
/*     */     
/*  86 */     this; addTask(50, (EntityAIBase)new EntityAICraftItems(this, craftSet, "villager_cook", null, 80, VillageStructureType.KITCHEN, Blocks.field_150462_ai, p -> p.isWorkTime()));
/*     */   }
/*     */   
/*     */   public void func_70636_d() {
/*  90 */     super.func_70636_d();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<Recipe> buildCraftSet() {
/* 111 */     List<Recipe> recipes = new ArrayList<>();
/*     */ 
/*     */     
/* 114 */     List<ItemStack> ingredients = new ArrayList<>();
/* 115 */     ingredients.add(new ItemStack(Items.field_151043_k, 8));
/* 116 */     ingredients.add(new ItemStack(Items.field_151034_e, 1));
/* 117 */     Recipe recipe1 = new Recipe(ProfessionType.CHEF, "craft_golden_apple", 2, new ItemStack(Items.field_151153_ao, 1), ingredients, 1, 1, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 7, 2)), 16);
/* 118 */     recipes.add(recipe1);
/*     */ 
/*     */     
/* 121 */     ingredients = new ArrayList<>();
/* 122 */     ingredients.add(new ItemStack(Items.field_151043_k, 1));
/* 123 */     ingredients.add(new ItemStack(Items.field_151172_bF, 1));
/* 124 */     recipe1 = new Recipe(ProfessionType.CHEF, "craft_golden_carrot", 2, new ItemStack(Items.field_151150_bK, 1), ingredients, 3, 3, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 7, 2)), 16);
/* 125 */     recipes.add(recipe1);
/*     */ 
/*     */     
/* 128 */     ingredients = new ArrayList<>();
/* 129 */     ingredients.add(new ItemStack(Items.field_185164_cV, 6));
/* 130 */     ingredients.add(new ItemStack(Items.field_151054_z, 1));
/* 131 */     recipe1 = new Recipe(ProfessionType.CHEF, "craft_beetroot_soup", 2, new ItemStack(Items.field_185165_cW, 1), ingredients, 2, 3, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 7, 2)), 15);
/* 132 */     recipes.add(recipe1);
/*     */ 
/*     */     
/* 135 */     ingredients = new ArrayList<>();
/* 136 */     ingredients.add(new ItemStack(Items.field_151117_aB, 3));
/* 137 */     ingredients.add(new ItemStack(Items.field_151102_aT, 2));
/* 138 */     ingredients.add(new ItemStack(Items.field_151110_aK, 1));
/* 139 */     ingredients.add(new ItemStack(Items.field_151015_O, 3));
/* 140 */     recipe1 = new Recipe(ProfessionType.CHEF, "craft_cake", 1, new ItemStack(Items.field_151105_aU, 1), ingredients, 1, 1, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 10, 5)), 1)
/*     */       {
/*     */         
/*     */         public ItemStack craft(EntityVillagerTek villager)
/*     */         {
/* 145 */           List<ItemStack> items = villager.getInventory().getItems(p -> (p.func_77973_b() == Items.field_151117_aB), 3);
/* 146 */           int villagerMilks = (int)items.stream().filter(itemStack -> ModItems.isTaggedItem(itemStack, ItemTagType.VILLAGER)).count();
/*     */           
/* 148 */           ItemStack result = super.craft(villager);
/* 149 */           if (result != null) {
/* 150 */             int nonVillagerMilks = 3 - villagerMilks;
/* 151 */             if (villagerMilks > 0)
/*     */             {
/* 153 */               villager.getInventory().func_174894_a(ModItems.makeTaggedItem(new ItemStack(Items.field_151133_ar, villagerMilks), ItemTagType.VILLAGER));
/*     */             }
/*     */             
/* 156 */             if (nonVillagerMilks > 0)
/*     */             {
/* 158 */               villager.getInventory().func_174894_a(new ItemStack(Items.field_151133_ar, nonVillagerMilks));
/*     */             }
/*     */           } 
/*     */           
/* 162 */           return result;
/*     */         }
/*     */       };
/* 165 */     recipes.add(recipe1);
/*     */ 
/*     */     
/* 168 */     ingredients = new ArrayList<>();
/* 169 */     ingredients.add(new ItemStack(Items.field_151015_O, 3));
/* 170 */     recipe1 = new Recipe(ProfessionType.CHEF, "craft_bread", 6, new ItemStack(Items.field_151025_P, 1), ingredients, 3, 5, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 5, 2)), 32);
/* 171 */     recipes.add(recipe1);
/*     */ 
/*     */     
/* 174 */     ingredients = new ArrayList<>();
/* 175 */     ingredients.add(new ItemStack(Item.func_150898_a(Blocks.field_150364_r), 1, 99));
/* 176 */     Predicate<EntityVillagerTek> pred = v -> !Recipe.hasPersonalGoal(v, new ItemStack(Items.field_151054_z, 3));
/* 177 */     Recipe recipe2 = new Recipe(ProfessionType.CHEF, "craft_wooden_bowl", 10, new ItemStack(Items.field_151054_z, 1), ingredients, 3, 3, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 5, 1)), 3, pred);
/* 178 */     recipes.add(recipe2);
/*     */ 
/*     */     
/* 181 */     ingredients = new ArrayList<>();
/* 182 */     ingredients.add(new ItemStack(Items.field_151120_aE, 1));
/* 183 */     pred = (v -> !Recipe.hasPersonalGoal(v, new ItemStack(Items.field_151102_aT, 6)));
/* 184 */     recipe2 = new Recipe(ProfessionType.CHEF, "craft_sugar", 15, new ItemStack(Items.field_151102_aT, 1), ingredients, 3, 4, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 3, 1)), 32, pred);
/* 185 */     recipes.add(recipe2);
/*     */ 
/*     */     
/* 188 */     ingredients = new ArrayList<>();
/* 189 */     ingredients.add(new ItemStack(Item.func_150898_a(Blocks.field_150423_aK), 1));
/* 190 */     ingredients.add(new ItemStack(Items.field_151102_aT, 1));
/* 191 */     ingredients.add(new ItemStack(Items.field_151110_aK, 1));
/* 192 */     Recipe recipe = new Recipe(ProfessionType.CHEF, "craft_pumpkin_pie", 2, new ItemStack(Items.field_151158_bO, 1), ingredients, 3, 4, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 9, 4)), 1);
/* 193 */     recipes.add(recipe);
/*     */ 
/*     */     
/* 196 */     ingredients = new ArrayList<>();
/* 197 */     ingredients.add(new ItemStack(Items.field_151015_O, 2));
/* 198 */     ingredients.add(new ItemStack(Items.field_151100_aR, 1, EnumDyeColor.BROWN.func_176767_b()));
/* 199 */     recipe = new Recipe(ProfessionType.CHEF, "craft_cookie", 4, new ItemStack(Items.field_151106_aX, 1), ingredients, 3, 3, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.CHEF, 6, 2)), 3);
/* 200 */     recipes.add(recipe);
/*     */ 
/*     */     
/* 203 */     return recipes;
/*     */   }
/*     */   
/*     */   private static Predicate<ItemStack> takeFromFurnace() {
/* 207 */     return p -> (isCooked().test(p) || p.func_77973_b() == Items.field_151044_h);
/*     */   }
/*     */   
/*     */   private static Predicate<ItemStack> isCooked() {
/* 211 */     return p -> (p.func_77973_b() == Items.field_151077_bg || p.func_77973_b() == Items.field_151083_be || p.func_77973_b() == Items.field_179557_bn || p.func_77973_b() == Items.field_151157_am || p.func_77973_b() == Items.field_151168_bH);
/*     */   }
/*     */   
/*     */   protected static boolean hasCoal(EntityVillagerTek villager, int req) {
/* 215 */     int count = villager.getInventory().getItemCount(isCoal());
/* 216 */     return (count >= req);
/*     */   }
/*     */   public static Predicate<ItemStack> isCoal() {
/* 219 */     return p -> (p.func_77973_b() == Items.field_151044_h);
/*     */   }
/*     */   private static Function<ItemStack, Integer> bestCookable(EntityVillagerTek villager) {
/* 222 */     return p -> 
/* 223 */       (p.func_77973_b() == Items.field_151082_bd && villager.isAIFilterEnabled("cook_beef")) ? EntityVillagerTek.foodItemValue(null).apply(Items.field_151083_be) : (
/*     */       
/* 225 */       (p.func_77973_b() == Items.field_151147_al && villager.isAIFilterEnabled("cook_pork")) ? EntityVillagerTek.foodItemValue(null).apply(Items.field_151157_am) : (
/*     */       
/* 227 */       (p.func_77973_b() == Items.field_151076_bf && villager.isAIFilterEnabled("cook_chicken")) ? EntityVillagerTek.foodItemValue(null).apply(Items.field_151077_bg) : (
/*     */       
/* 229 */       (p.func_77973_b() == Items.field_179561_bm && villager.isAIFilterEnabled("cook_mutton")) ? EntityVillagerTek.foodItemValue(null).apply(Items.field_179557_bn) : (
/*     */       
/* 231 */       (p.func_77973_b() == Items.field_151174_bG && villager.isAIFilterEnabled("cook_potato")) ? EntityVillagerTek.foodItemValue(null).apply(Items.field_151168_bH) : Integer.valueOf(-1)))));
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityChef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */