/*    */ package net.tangotek.tektopia.commands;
/*    */ 
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.command.WrongUsageException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.init.SoundEvents;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.util.SoundCategory;
/*    */ import net.tangotek.tektopia.structures.VillageStructureType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CommandStart
/*    */   extends CommandVillageBase
/*    */ {
/*    */   public CommandStart() {
/* 29 */     super("start");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
/* 35 */     if (args.length > 0)
/*    */     {
/* 37 */       throw new WrongUsageException("commands.village.start.usage", new Object[0]);
/*    */     }
/*    */ 
/*    */     
/* 41 */     EntityPlayerMP entityPlayerMP = func_71521_c(sender);
/*    */     
/* 43 */     boolean flag = ((EntityPlayer)entityPlayerMP).field_71071_by.func_70441_a(VillageStructureType.TOWNHALL.itemStack.func_77946_l());
/* 44 */     flag |= ((EntityPlayer)entityPlayerMP).field_71071_by.func_70441_a(VillageStructureType.STORAGE.itemStack.func_77946_l());
/*    */     
/* 46 */     if (flag) {
/*    */       
/* 48 */       ((EntityPlayer)entityPlayerMP).field_70170_p.func_184148_a((EntityPlayer)null, ((EntityPlayer)entityPlayerMP).field_70165_t, ((EntityPlayer)entityPlayerMP).field_70163_u, ((EntityPlayer)entityPlayerMP).field_70161_v, SoundEvents.field_187638_cR, SoundCategory.PLAYERS, 0.2F, ((entityPlayerMP.func_70681_au().nextFloat() - entityPlayerMP.func_70681_au().nextFloat()) * 0.7F + 1.0F) * 2.0F);
/* 49 */       ((EntityPlayer)entityPlayerMP).field_71069_bz.func_75142_b();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\commands\CommandStart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */