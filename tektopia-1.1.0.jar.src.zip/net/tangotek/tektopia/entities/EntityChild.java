/*     */ package net.tangotek.tektopia.entities;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.SoundEvent;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.DifficultyInstance;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.TekVillager;
/*     */ import net.tangotek.tektopia.Village;
/*     */ import net.tangotek.tektopia.VillagerRole;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIGenericMove;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIPlayTag;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAISchoolAttend;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ import net.tangotek.tektopia.structures.VillageStructureType;
/*     */ 
/*     */ public class EntityChild
/*     */   extends EntityVillagerTek
/*     */ {
/*  30 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityChild.class);
/*     */   
/*  32 */   private static final DataParameter<Byte> VARIATION = EntityDataManager.func_187226_a(EntityChild.class, DataSerializers.field_187191_a);
/*  33 */   private static final DataParameter<Boolean> PLAY_TAG = EntityDataManager.func_187226_a(EntityChild.class, DataSerializers.field_187198_h);
/*  34 */   private static final DataParameter<Boolean> ATTEND_SCHOOL = EntityDataManager.func_187226_a(EntityChild.class, DataSerializers.field_187198_h);
/*     */   
/*  36 */   protected EntityChild chasedBy = null;
/*     */   protected boolean attendedSchoolToday = false;
/*     */   private int daysForAdult;
/*     */   
/*     */   static {
/*  41 */     animHandler.addAnim("tektopia", "villager_skip", "child_m", true);
/*  42 */     animHandler.addAnim("tektopia", "villager_sit_raise", "child_m", false);
/*  43 */     EntityVillagerTek.setupAnimations(animHandler, "child_m");
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityChild(World worldIn) {
/*  48 */     super(worldIn, ProfessionType.CHILD, VillagerRole.VILLAGER.value);
/*  49 */     func_70105_a(this.field_70130_N * 0.5F, this.field_70131_O * 0.5F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/*  59 */     return animHandler;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public IEntityLivingData func_180482_a(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata) {
/*  64 */     setVariation(Byte.valueOf((byte)this.field_70146_Z.nextInt(2)));
/*  65 */     return super.func_180482_a(difficulty, livingdata);
/*     */   }
/*     */   
/*     */   protected void func_70088_a() {
/*  69 */     super.func_70088_a();
/*  70 */     this.field_70180_af.func_187214_a(VARIATION, Byte.valueOf((byte)this.field_70146_Z.nextInt(2)));
/*  71 */     registerAIFilter("play_tag", PLAY_TAG);
/*  72 */     registerAIFilter("attend_school", ATTEND_SCHOOL);
/*     */     
/*  74 */     removeAIFilter("visit_tavern");
/*     */   }
/*     */   
/*     */   protected void func_184651_r() {
/*  78 */     super.func_184651_r();
/*     */     
/*  80 */     this.daysForAdult = 4 + func_70681_au().nextInt(2);
/*     */     
/*  82 */     addTask(50, (EntityAIBase)new EntityAISchoolAttend(this, p -> (p.isWorkTime() && needsSchoolToday())));
/*  83 */     addTask(50, (EntityAIBase)new EntityAIPlayTag(this));
/*  84 */     addTask(50, (EntityAIBase)new EntityAIGenericMove(this, p -> (p.isWorkTime() && p.hasVillage() && p.func_70681_au().nextInt(2) == 0), v -> this.village.getLastVillagerPos(), EntityVillagerTek.MovementMode.SKIP, null, null));
/*  85 */     addTask(50, (EntityAIBase)new EntityAIGenericMove(this, p -> (p.isWorkTime() && p.hasVillage()), v -> this.village.getLastVillagerPos(), EntityVillagerTek.MovementMode.WALK, null, null));
/*     */   }
/*     */   
/*     */   protected void onNewDay() {
/*  89 */     super.onNewDay();
/*  90 */     checkGrowAdult();
/*     */   }
/*     */ 
/*     */   
/*     */   public void attachToVillage(Village v) {
/*  95 */     super.attachToVillage(v);
/*  96 */     this.sleepOffset = genOffset(400) - 1200;
/*     */   }
/*     */   
/*     */   protected void setupServerJobs() {
/* 100 */     super.setupServerJobs();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addTask(int priority, EntityAIBase task) {
/* 106 */     if (task instanceof net.tangotek.tektopia.entities.ai.EntityAIReadBook) {
/*     */       return;
/*     */     }
/* 109 */     super.addTask(priority, task);
/*     */   }
/*     */   
/*     */   protected void setVariation(Byte v) {
/* 113 */     this.field_70180_af.func_187227_b(VARIATION, Byte.valueOf(v.byteValue()));
/*     */   }
/*     */   
/*     */   public Byte getVariation() {
/* 117 */     return Byte.valueOf(((Byte)this.field_70180_af.func_187225_a(VARIATION)).byteValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStartSleep(int sleepAxis) {
/* 122 */     super.onStartSleep(sleepAxis);
/* 123 */     this.attendedSchoolToday = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStartSit(int sitAxis) {
/* 128 */     VillageStructure curStruct = getCurrentStructure();
/* 129 */     if (curStruct != null && curStruct.type == VillageStructureType.SCHOOL) {
/* 130 */       this.attendedSchoolToday = true;
/*     */     }
/*     */     
/* 133 */     super.onStartSit(sitAxis);
/*     */   }
/*     */   
/*     */   public double getSitOffset() {
/* 137 */     return 0.24D;
/*     */   }
/*     */   
/*     */   public boolean needsSchoolToday() {
/* 141 */     return !this.attendedSchoolToday;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70631_g_() {
/* 147 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canConvertProfession(ProfessionType pt) {
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float func_70047_e() {
/* 158 */     return 0.87F;
/*     */   }
/*     */   
/*     */   protected boolean wantsTavern() {
/* 162 */     return false;
/*     */   }
/*     */   
/*     */   public void func_70636_d() {
/* 166 */     super.func_70636_d();
/*     */   }
/*     */   
/*     */   protected boolean canVillagerPickupItem(ItemStack itemIn) {
/* 170 */     return super.canVillagerPickupItem(itemIn);
/*     */   }
/*     */   
/*     */   protected void cleanUpInventory() {
/* 174 */     super.cleanUpInventory();
/*     */   }
/*     */   
/*     */   protected void checkGrowAdult() {
/* 178 */     if (this.daysAlive >= this.daysForAdult) {
/* 179 */       EntityVillagerTek villager = new EntityNitwit(this.field_70170_p);
/* 180 */       villager.func_70012_b(this.field_70165_t, this.field_70163_u, this.field_70161_v, 0.0F, 0.0F);
/* 181 */       villager.func_180482_a(this.field_70170_p.func_175649_E(func_180425_c()), (IEntityLivingData)null);
/* 182 */       villager.cloneFrom(this);
/* 183 */       this.field_70170_p.func_72838_d((Entity)villager);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float func_70689_ay() {
/* 190 */     return super.func_70689_ay() * 0.75F;
/*     */   }
/*     */   
/*     */   public void setChasedBy(EntityChild child) {
/* 194 */     this.chasedBy = child;
/*     */   }
/*     */   
/*     */   public EntityChild getChasedBy() {
/* 198 */     return this.chasedBy;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFleeFrom(Entity e) {
/* 203 */     return (e == this.chasedBy || super.isFleeFrom(e));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void playSound(SoundEvent soundEvent) {
/* 209 */     func_184185_a(soundEvent, func_70681_au().nextFloat() * 0.4F + 0.8F, func_70681_au().nextFloat() * 0.4F + 1.1F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound compound) {
/* 215 */     super.func_70014_b(compound);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound compound) {
/* 220 */     super.func_70037_a(compound);
/*     */   }
/*     */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityChild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */