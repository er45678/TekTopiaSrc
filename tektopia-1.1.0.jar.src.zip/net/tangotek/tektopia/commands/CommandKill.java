/*    */ package net.tangotek.tektopia.commands;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.command.WrongUsageException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*    */ 
/*    */ 
/*    */ 
/*    */ class CommandKill
/*    */   extends CommandVillageBase
/*    */ {
/*    */   public CommandKill() {
/* 18 */     super("kill");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
/* 24 */     if (args.length > 0)
/*    */     {
/* 26 */       throw new WrongUsageException("commands.village.kill.usage", new Object[0]);
/*    */     }
/*    */     
/* 29 */     EntityPlayerMP entityPlayerMP = func_71521_c(sender);
/* 30 */     List<EntityVillageNavigator> villagers = ((EntityPlayer)entityPlayerMP).field_70170_p.func_72872_a(EntityVillageNavigator.class, entityPlayerMP.func_174813_aQ().func_72314_b(200.0D, 200.0D, 200.0D));
/* 31 */     for (EntityVillageNavigator villager : villagers)
/* 32 */       villager.func_70106_y(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\ryder\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\commands\CommandKill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */